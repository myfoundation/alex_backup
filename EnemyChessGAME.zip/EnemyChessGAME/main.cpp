#include "stdafx.h"
#include "DOSEmu.h"
#include "KEY_BOARD.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <string_view>


using namespace std;

#define SCREEN_WIDTH          70
#define SCREEN_HEIGTH         30

#define MAX_MAP_HEIGTH        500

#define K_STATE_RUN_RIGHT     0
#define K_STATE_RUN_LEFT      1
#define K_STATE_JUMP_UP       2
#define K_STATE_JUMP_DOWN     3
#define K_STATE_WATCH_RIGHT   4
#define K_STATE_WATCH_LEFT    5
#define K_STATE_DIYING        6
#define K_STATE_DEAD          7

#define Q_K_STATES            8

#define Q_K_FRAMES            20

#define MAX_KNIGHT_WIDTH      50
#define MAX_KNIGHT_HEIGTH     50

#define Q_JUMP_UP_ADDS        500

#define MAX_Q_FRAMES_IN_ANIMATION  6000

#define MAX_LAYER_WIDTH       500
#define MAX_LAYER_HEIGTH      500
#define MAX_LAYER_NUM_FRAMES  10

#define MAX_Q_LAYERS          7

#define ENEMY_STATE_ALIVE     0
#define ENEMY_STATE_DIE       1
#define ENEMY_STATE_DIEING    2

#define Q_ENEMY_STATES        3

#define Q_ENEMY_FRAMES        18

#define MAX_Q_ENEMYES         500

#define ENEMY_TYPE_BISHOP     0
#define ENEMY_TYPE_ROOK       1
#define ENEMY_TYPE_PAWN       2
#define ENEMY_TYPE_KNIGHT     3
#define ENEMY_TYPE_QUEEN      4

#define Q_ENEMY_TYPES         5

#define MAX_ENEMY_WIDTH       50
#define MAX_ENEMY_HEIGTH      50

#define Q_BULLET_FRAMES       3
#define Q_BULLET_FRAMES_IN_ANIMATION 300

#define MAX_Q_BULLETS          10000
#define Q_BULLETS              10000
#define MAX_BULLET_WIDTH       50
#define MAX_BULLET_HEIGTH      50


#define G_S_PLAYING            0
#define G_S_WIN                1
#define G_S_LOSE               2


#define Q_ITERATIONS_IF_WIN    10000

#define MAX_Q_SCREEN_SAVERS    100



struct knight
{
int state;
int scr_off_x, scr_off_y;
int width, heigth, old_width, old_heigth;
int body_width, body_heigth;
double x, y;
double dieing_x, dieing_y;
string frames[Q_K_FRAMES];
string body[Q_K_FRAMES];
string visiably_part[Q_K_FRAMES];
int num_frame;
int state_clock;
int states_q_frames[Q_K_STATES] = {48*2, 48*2, Q_JUMP_UP_ADDS, 1, 1, 1, 5000, 5000};
int flag_to_move_screen_by_width_and_heigth[Q_K_FRAMES] = {1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0};
int frames_for_states[Q_K_STATES][MAX_Q_FRAMES_IN_ANIMATION] = {{2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                                                                 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                                                                 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4},
                                                                {5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
                                                                 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
                                                                 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7},
                                                                {},
                                                                {8}, {0}, {1}, {}, {16}};
int q_indexes_of_frames_in_deing_animation = 7;
int indexes_of_frames_in_deing_animation[MAX_Q_FRAMES_IN_ANIMATION] = {0, 15, 12, 13, 17, 18, 19};
int jump_up_table_index;
};

struct layer
{
double velocity;
double screen_velocity;
double clock_velocity;
int clock_frames;
int prioritet;
int width, heigth;
int q_frames;
int num_frame;
int frames_time_table[MAX_LAYER_NUM_FRAMES];
char layer[MAX_LAYER_WIDTH][MAX_LAYER_HEIGTH][MAX_LAYER_NUM_FRAMES];
};

struct label
{
int width, heigth;
char label[MAX_LAYER_WIDTH][MAX_LAYER_HEIGTH];
char animated_label[MAX_LAYER_WIDTH][MAX_LAYER_HEIGTH];
};

struct screensaver
{
int width, heigth;
char picture[MAX_LAYER_WIDTH][MAX_LAYER_HEIGTH];
char animated_picture[MAX_LAYER_WIDTH][MAX_LAYER_HEIGTH];
int q_ticks_to_animate;
int clock;
int clock_to_dissapear;
int rand_seed;
};

struct bullet
{
double x, y, v_x, v_y;
int clock; // when 0 - it dissapears
int num_frame;
int clock_frame;
string frames[Q_ENEMY_FRAMES];
int q_index_of_frames = 3;
int indexes_of_frames[Q_BULLET_FRAMES] = {0, 1, 2};
int q_frames = 3;
int q_frames_in_animation = 300;
int frames_animation[MAX_Q_FRAMES_IN_ANIMATION];
};

struct enemy
{
double x, y;
double dieing_x, dieing_y;
int state;
int clock;
int enemy_type;
int frame_clock;
int width, heigth, old_width, old_heigth;
int body_width, body_heigth;
int q_indexes_of_frames_in_deing_animation[Q_ENEMY_TYPES] = {4, 4, 4, 4, 4};
int indexes_of_frames_in_deing_animation[Q_ENEMY_TYPES][MAX_Q_FRAMES_IN_ANIMATION] = {{2, 3, 4, 5}, {2, 3, 4, 5}, {2, 3, 4, 5}, {2, 3, 4, 5}, {2, 3, 4, 5}};
int q_frames_in_deing_animation[Q_ENEMY_TYPES] = {1700, 1700, 1700, 1700, 1700};
int q_frames_in_animation[Q_ENEMY_TYPES] = {1000, 1000, 500, 1000, 1002};
int indexes_of_frames_in_animation[Q_ENEMY_TYPES][MAX_Q_FRAMES_IN_ANIMATION] = {{0, 1}, {6, 7, 8, 7}, {9, 10}, {11, 12, 13, 12}, {14, 15, 17, 16, 17, 15}};
int q_indexes_of_frames_in_animation[Q_ENEMY_TYPES] = {2, 4, 2, 4, 6};
int states_q_frames[Q_ENEMY_STATES] = {MAX_Q_FRAMES_IN_ANIMATION, 0, 1};
int frames_for_states[Q_ENEMY_TYPES][Q_ENEMY_STATES][MAX_Q_FRAMES_IN_ANIMATION] = {{{0, 1}, {}, {0}},
                                                                                    {{6, 7, 8, 7}, {}, {0}},
                                                                                    {{9, 10}, {}, {0}},
                                                                                    {{11, 12, 13}, {}, {0}},
                                                                                    {{14, 15, 16, 17, 16, 15}, {}, {0}}};
string frames[Q_ENEMY_FRAMES];
string body[Q_ENEMY_FRAMES];
string visiably_part[Q_ENEMY_FRAMES];
int num_frame;

int first_bullet_clocks[Q_ENEMY_TYPES] = {200, 200, 100, 200, 200};
int clock_to_fire[Q_ENEMY_TYPES]   = {1000, 500, 500, 1000, 200};
int bullets_clock[Q_ENEMY_TYPES]   = {1500, 1000, 1000, 1000, 1000};
int bullet_x_offset[Q_ENEMY_TYPES] = {2, 3, 2, 1, 3};
int bullet_y_offset[Q_ENEMY_TYPES] = {1, 1, 1, 1, 1};
double bullet_v_x[Q_ENEMY_TYPES]   = {-0.01, 0, -0.01, -0.01, 0};
double bullet_v_y[Q_ENEMY_TYPES]   = {0, -0.01, 0, 0, -0.01};
};

int G_S;

knight main_knight;
layer layers[MAX_Q_LAYERS];
int q_layers = 2;

label lose_label, win_label;
screensaver _screensaver[MAX_Q_SCREEN_SAVERS];
int q_screensavers = 3;
int win_index = Q_ITERATIONS_IF_WIN;

enemy enemyes[MAX_Q_ENEMYES];

double enemyes_x[MAX_Q_ENEMYES];
double enemyes_y[MAX_Q_ENEMYES];
int enemyes_types[MAX_Q_ENEMYES];

bullet bullets[MAX_Q_BULLETS];
int q_enemyes;

char screen[SCREEN_WIDTH][SCREEN_HEIGTH];

int MAP_WIDTH  = 624;
int MAP_HEIGTH = 40;

string _map[MAX_MAP_HEIGTH];

bool is_knight_crashed_into_map();
bool is_knight_falling();
void try_set_pixel_to_screen(int x, int y, char color);

void goto_for_cursor(int x, int y)
{
COORD coord;
coord.X = x;
coord.Y = y;
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void Blinking(int off=99)// hide cursor
{
void* handle = GetStdHandle(STD_OUTPUT_HANDLE);
CONSOLE_CURSOR_INFO structCursorInfo;
GetConsoleCursorInfo(handle,&structCursorInfo);
structCursorInfo.bVisible = FALSE;
SetConsoleCursorInfo( handle, &structCursorInfo);
}

void draw_screen()
{
int i_x, i_y;
string s;

for(i_y=0; i_y<SCREEN_HEIGTH; i_y++)
    {
    for(i_x=0; i_x<SCREEN_WIDTH; i_x++)
        {
        s+=screen[i_x][i_y];
        }
    s+='\n';
    }

goto_for_cursor(0, 0);
cout << s << flush;
}

void get_screensaver(int i_screen_saver)
{
int i_x, i_y;
for(i_x=0; i_x<_screensaver[i_screen_saver].width; i_x++)
    {
    for(i_y=0; i_y<_screensaver[i_screen_saver].heigth; i_y++)
        {
        if(_screensaver[i_screen_saver].picture[i_x][i_y] != ' ')
            {
            if(rand()%_screensaver[i_screen_saver].rand_seed==0)
                {
                _screensaver[i_screen_saver].animated_picture[i_x][i_y] = '*';
                }
            else
                {
                _screensaver[i_screen_saver].animated_picture[i_x][i_y] = _screensaver[i_screen_saver].picture[i_x][i_y];
                }
            }
        }
    }
}

void move_screensaver_to_screen(int i_screen_saver)
{
int i_x, i_y;
for(i_x=0; i_x<SCREEN_WIDTH; i_x++)
    {
    for(i_y=0; i_y<SCREEN_HEIGTH; i_y++)
        {
        screen[i_x][i_y] = ' ';
        }

    }

for(i_x=(SCREEN_WIDTH - _screensaver[i_screen_saver].width)/2; i_x<(SCREEN_WIDTH + _screensaver[i_screen_saver].width)/2; i_x++)
    {
    for(i_y=(SCREEN_HEIGTH - _screensaver[i_screen_saver].heigth)/2; i_y<(SCREEN_HEIGTH + _screensaver[i_screen_saver].heigth)/2; i_y++)
        {
        screen[i_x][i_y] = _screensaver[i_screen_saver].animated_picture[i_x - (SCREEN_WIDTH - _screensaver[i_screen_saver].width)/2][i_y - (SCREEN_HEIGTH - _screensaver[i_screen_saver].heigth)/2];
        }
    }
}

void init_screensavers()
{
int index, i_x, i_y, flag_of_string_end;
char ch;
FILE *stream[MAX_Q_SCREEN_SAVERS];

fopen_s(&stream[0], "screensaver1.txt", "r");

_screensaver[0].width  = 15;
_screensaver[0].heigth = 2;
_screensaver[0].clock_to_dissapear = 5000;
_screensaver[0].clock = 0;
_screensaver[0].q_ticks_to_animate = 500;
_screensaver[0].rand_seed = 5;

fopen_s(&stream[1], "screensaver2.txt", "r");

_screensaver[1].width  = 62;
_screensaver[1].heigth = 24;
_screensaver[1].clock_to_dissapear = 10000;
_screensaver[1].clock = 0;
_screensaver[1].q_ticks_to_animate = 500;
_screensaver[1].rand_seed = 5;

fopen_s(&stream[2], "screensaver3.txt", "r");

_screensaver[2].width  = 60;
_screensaver[2].heigth = 23;
_screensaver[2].clock_to_dissapear = 10000;
_screensaver[2].clock = 0;
_screensaver[2].q_ticks_to_animate = 500;
_screensaver[2].rand_seed = 5;

for(index=0; index<q_screensavers; index++)
    {

    for(i_y=0; i_y<_screensaver[index].heigth; i_y++)
        {
        flag_of_string_end=0;
        for(i_x=0; i_x<_screensaver[index].width; i_x++)
            {
            if(flag_of_string_end==0)
                {
                ch = fgetc(stream[index]);
                if(ch == '\n')
                    {
                    _screensaver[index].picture[i_x][i_y] = ' ';
                    _screensaver[index].animated_picture[i_x][i_y] = ' ';
                    flag_of_string_end = 1;
                    }
                else
                    {
                    if(ch != ' ')
                        {
                        _screensaver[index].picture[i_x][i_y] = ch;
                        _screensaver[index].animated_picture[i_x][i_y] = ch;
                        }
                    else
                        {
                        _screensaver[index].picture[i_x][i_y] = ' ';
                        _screensaver[index].animated_picture[i_x][i_y] = ' ';
                        }
                    }
                }
            else
                {
                _screensaver[index].picture[i_x][i_y] = ' ';
                _screensaver[index].animated_picture[i_x][i_y] = ' ';
                }
            }
        }
    }

for(index=0; index<q_screensavers; index++)
    {
    fclose(stream[index]);
    }

}

void init_win_label()
{
int index, i_x, i_y, flag_of_string_end;
char ch;
FILE *stream;

fopen_s(&stream, "win_text.txt", "r");

win_label.width  = 59;
win_label.heigth = 7;

for(i_y=0; i_y<win_label.heigth; i_y++)
    {
    flag_of_string_end=0;
    for(i_x=0; i_x<win_label.width; i_x++)
        {
        if(flag_of_string_end==0)
            {
            ch = fgetc(stream);
            if(ch == '\n')
                {
                win_label.label[i_x][i_y] = ' ';
                win_label.animated_label[i_x][i_y] = ' ';
                flag_of_string_end = 1;
                }
            else
                {
                if(ch != ' ')
                    {
                    win_label.label[i_x][i_y] = ch;
                    win_label.animated_label[i_x][i_y] = ch;
                    }
                else
                    {
                    win_label.label[i_x][i_y] = ' ';
                    win_label.animated_label[i_x][i_y] = ' ';
                    }
                }
            }
        else
            {
            win_label.label[i_x][i_y] = ' ';
            win_label.animated_label[i_x][i_y] = ' ';
            }
        }
    }
fclose(stream);
}

void init_lose_label()
{
int index, i_x, i_y, flag_of_string_end;
char ch;
FILE *stream;

fopen_s(&stream, "lose_text.txt", "r");

lose_label.width  = 54;
lose_label.heigth = 7;

for(i_y=0; i_y<lose_label.heigth; i_y++)
    {
    flag_of_string_end=0;
    for(i_x=0; i_x<lose_label.width; i_x++)
        {
        if(flag_of_string_end==0)
            {
            ch = fgetc(stream);
            if(ch == '\n')
                {
                lose_label.label[i_x][i_y] = ' ';
                lose_label.animated_label[i_x][i_y] = ' ';
                flag_of_string_end = 1;
                }
            else
                {
                if(ch != ' ')
                    {
                    lose_label.label[i_x][i_y] = ch;
                    lose_label.animated_label[i_x][i_y] = ch;
                    }
                else
                    {
                    lose_label.label[i_x][i_y] = ' ';
                    lose_label.animated_label[i_x][i_y] = ' ';
                    }
                }
            }
        else
            {
            lose_label.label[i_x][i_y] = ' ';
            lose_label.animated_label[i_x][i_y] = ' ';
            }
        }
    }
fclose(stream);
}

void redraw_lose_label()
{
int i_x, i_y;
for(i_x=0; i_x<lose_label.width; i_x++)
    {
    for(i_y=0; i_y<lose_label.heigth; i_y++)
        {
        if(lose_label.label[i_x][i_y] != ' ')
            {
            if(rand()%3==0)
                {
                lose_label.animated_label[i_x][i_y] = '*';
                }
            else
                {
                lose_label.animated_label[i_x][i_y] = lose_label.label[i_x][i_y];
                }
            }
        }
    }
}

void draw_lose_label()
{
int i_x, i_y;
for(i_x=0; i_x<lose_label.width; i_x++)
    {
    for(i_y=0; i_y<lose_label.heigth; i_y++)
        {
        if(lose_label.label[i_x][i_y] != ' ')
            {
                try_set_pixel_to_screen(i_x+SCREEN_WIDTH/2-lose_label.width/2,
                                        i_y+SCREEN_HEIGTH/2-lose_label.heigth/2, lose_label.animated_label[i_x][i_y]);
            }
        }
    }
}

void redraw_win_label()
{
int i_x, i_y;
for(i_x=0; i_x<win_label.width; i_x++)
    {
    for(i_y=0; i_y<win_label.heigth; i_y++)
        {
        if(win_label.label[i_x][i_y] != ' ')
            {
            if(rand()%3==0)
                {
                win_label.animated_label[i_x][i_y] = '*';
                }
            else
                {
                win_label.animated_label[i_x][i_y] = win_label.label[i_x][i_y];
                }
            }
        }
    }
}

void draw_win_label()
{
int i_x, i_y;
for(i_x=0; i_x<win_label.width; i_x++)
    {
    for(i_y=0; i_y<win_label.heigth; i_y++)
        {
        if(win_label.label[i_x][i_y] != ' ')
            {
                try_set_pixel_to_screen(i_x+SCREEN_WIDTH/2-win_label.width/2,
                                        i_y+SCREEN_HEIGTH/2-win_label.heigth/2, win_label.animated_label[i_x][i_y]);
            }
        }
    }
}

void init_layers()
{
int index, i_x, i_y, flag_of_string_end;
char ch;
FILE *stream[q_layers];

fopen_s(&stream[0], "layer_1.txt", "r");

layers[0].width                = 79;
layers[0].heigth               = 40;
layers[0].q_frames             = 1;
layers[0].frames_time_table[0] = 10;
layers[0].prioritet            = 0;
layers[0].clock_frames         = 0;
layers[0].clock_velocity       = 0;
layers[0].velocity             = 0;//0.01;
layers[0].num_frame            = 0;
layers[0].screen_velocity      = 1;//0.99;

for(i_y=0; i_y<layers[0].heigth; i_y++)
    {
    flag_of_string_end=0;
    for(i_x=0; i_x<layers[0].width; i_x++)
        {
        if(flag_of_string_end==0)
            {
            ch = fgetc(stream[0]);
            if(ch == '\n')
                {
                layers[0].layer[i_x][i_y][0] = ' ';
                flag_of_string_end = 1;
                }
            else
                {
                if(ch != ' ')
                    {
                    layers[0].layer[i_x][i_y][0] = ch;
                    }
                else
                    {
                    layers[0].layer[i_x][i_y][0] = ' ';
                    }
                }
            }
        else
            {
            layers[0].layer[i_x][i_y][0] = ' ';
            }
        }
    }

fopen_s(&stream[1], "layer_2.txt", "r");

layers[1].width                = 81;
layers[1].heigth               = 40;
layers[1].q_frames             = 1;
layers[1].frames_time_table[0] = 10;
layers[1].prioritet            = 1;
layers[1].clock_frames         = 0;
layers[1].clock_velocity       = 0;
layers[1].velocity             = 0;
layers[1].num_frame            = 0;
layers[1].screen_velocity      = 2;

for(i_y=0; i_y<layers[1].heigth; i_y++)
    {
    flag_of_string_end=0;
    for(i_x=0; i_x<layers[1].width; i_x++)
        {
        if(flag_of_string_end==0)
            {
            ch = fgetc(stream[1]);
            if(ch == '\n')
                {
                layers[1].layer[i_x][i_y][0] = ' ';
                flag_of_string_end = 1;
                }
            else
                {
                if(ch != ' ')
                    {
                    layers[1].layer[i_x][i_y][0] = ch;
                    }
                else
                    {
                    layers[1].layer[i_x][i_y][0] = ' ';
                    }
                }
            }
        else
            {
            layers[1].layer[i_x][i_y][0] = ' ';
            }
        }
    }

for(index=0; index<q_layers; index++)
    {
    fclose(stream[index]);
    }
}

void change_layers_state()
{
int index;
for(index=0; index<q_layers; index++)
    {
    layers[index].clock_velocity += 1;
    if(layers[index].clock_velocity*layers[index].velocity >= layers[index].width)
        {
        if(layers[index].velocity != 0)
            {
            layers[index].clock_velocity = (layers[index].clock_velocity*layers[index].velocity
                                           - layers[index].width) / layers[index].velocity;
            }
        else
            {
            layers[index].clock_velocity = 0;
            }

        }

    layers[index].clock_frames += 1;

    if(layers[index].clock_frames > layers[index].frames_time_table[layers[index].num_frame])
        {
        layers[index].clock_frames =  0;
        layers[index].num_frame    += 1;
        if(layers[index].num_frame >= layers[index].q_frames)
            {
            layers[index].num_frame = 0;
            }
        }
    }
}

char get_pixel_from_layer(int x_start, int y_start, int layer_index)
{
int x, y;
char res;

x = x_start + (layers[layer_index].velocity*layers[layer_index].clock_velocity);
y = y_start;

while(x>=layers[layer_index].width)
    {
    x-=layers[layer_index].width;
    }

while(y>=layers[layer_index].heigth)
    {
    y-=layers[layer_index].heigth;
    }

while(x<0)
    {
    x+=layers[layer_index].width;
    }

while(y<0)
    {
    y+=layers[layer_index].heigth;
    }

res = layers[layer_index].layer[x][y][layers[layer_index].num_frame];

return(res);
}

char get_pixel_from_layers(int x_scr, int y_scr, int x, int y)
{
int index_of_prioritet, index_of_layer;
char ch, res;

for(index_of_prioritet=0; index_of_prioritet<q_layers; index_of_prioritet++)
    {
    for(index_of_layer=0; index_of_layer<q_layers; index_of_layer++)
        {
        if(layers[index_of_layer].prioritet == index_of_prioritet)
            {
            ch = get_pixel_from_layer((x+(x_scr*layers[index_of_layer].screen_velocity)),
                                      y+y_scr, index_of_layer);
            if(ch != ' ' || index_of_prioritet==0)
                {
                res = ch;
                }
            }
        }
    }
return res;
}

void init_map()
{
int i_x, i_y;
FILE *stream;
int flag_of_string_end;
char ch;
string temp;
fopen_s(&stream, "map.txt", "r");

for(i_y=0; i_y<MAP_HEIGTH; i_y++)
    {
    temp = "";
    for(i_x=0; i_x<MAP_WIDTH; i_x++)
        {
        temp += " ";
        }
    _map[i_y] = temp;
    }


for(i_y=0; i_y<MAP_HEIGTH; i_y++)
    {
    flag_of_string_end=0;
    for(i_x=0; i_x<MAP_WIDTH+1; i_x++) // because last is /n
        {
        if(flag_of_string_end==0)
            {
            ch = fgetc(stream);
            if(ch == '\n')
                {
                _map[i_y][i_x] = ' ';
                flag_of_string_end = 1;
                }
            else
                {
                if(ch != ' ')
                    {
                    _map[i_y][i_x] = ch;
                    }
                else
                    {
                    _map[i_y][i_x] = ' ';
                    }
                }
            }
        else
            {
            _map[i_y][i_x] = ' ';
            }
        }
    }

}

void init_main_knight()
{
int index, index1, index2;
string input;
char ch;
int end_flag=0, frame_index=0, body_index=0, k_frame_body_open_index=0;
FILE *stream;

main_knight.state     = K_STATE_WATCH_RIGHT;

main_knight.jump_up_table_index = 0;

main_knight.x         = 5;
main_knight.y         = 0.99;

fopen_s(&stream, "knight_sprites.txt", "r");

string k_sprite_open_token = "<sprite_knight>", k_sprite_close_token = "</sprite_knight>",
       eof_token = "<end>", k_body_open_token = "<knight_body>", k_body_close_token = "</knight_body>",
       k_frame_body_open_token = "<visible_knight>", k_frame_body_close_token = "</visible_knight>";

while(!end_flag)
    {
    ch = fgetc(stream);
    input += ch;
    if(input.find(k_sprite_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(k_sprite_close_token) != string::npos)
        {
        input.erase(input.length()-k_sprite_close_token.length());
        main_knight.frames[frame_index] = input;
        frame_index += 1;
        input = "";
        }

    if(input.find(k_body_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(k_body_close_token) != string::npos)
        {
        input.erase(input.length()-k_body_close_token.length());
        main_knight.body[body_index] = input;
        body_index += 1;
        input = "";
        }


    if(input.find(k_frame_body_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(k_frame_body_close_token) != string::npos)
        {
        input.erase(input.length()-k_frame_body_close_token.length());
        main_knight.visiably_part[k_frame_body_open_index] = input;
        k_frame_body_open_index += 1;
        input = "";
        }

    if(input.find(eof_token) != string::npos)
        {
        end_flag=1;
        input = "";
        }
    }

// jumps
for(index=0; index<Q_JUMP_UP_ADDS/5; index++)
    {
    main_knight.frames_for_states[K_STATE_JUMP_UP][index] = 8;
    }
for(index=1*Q_JUMP_UP_ADDS/5; index<2*Q_JUMP_UP_ADDS/5; index++)
    {
    main_knight.frames_for_states[K_STATE_JUMP_UP][index] = 9;
    }
for(index=2*Q_JUMP_UP_ADDS/5; index<3*Q_JUMP_UP_ADDS/5; index++)
    {
    main_knight.frames_for_states[K_STATE_JUMP_UP][index] = 10;
    }
for(index=3*Q_JUMP_UP_ADDS/5; index<4*Q_JUMP_UP_ADDS/5; index++)
    {
    main_knight.frames_for_states[K_STATE_JUMP_UP][index] = 11;
    }
for(index=4*Q_JUMP_UP_ADDS/5; index<Q_JUMP_UP_ADDS; index++)
    {
    main_knight.frames_for_states[K_STATE_JUMP_UP][index] = 14;
    }

// dieing animation
index2 = 0;

main_knight.states_q_frames[K_STATE_DIYING] -= main_knight.states_q_frames[K_STATE_DIYING] %
    main_knight.q_indexes_of_frames_in_deing_animation;

for(index=0; index<main_knight.q_indexes_of_frames_in_deing_animation; index++)
    {
    for(index1=0; index1<main_knight.states_q_frames[K_STATE_DIYING]/main_knight.q_indexes_of_frames_in_deing_animation; index1++)
        {
        main_knight.frames_for_states[K_STATE_DIYING][index2] = main_knight.indexes_of_frames_in_deing_animation[index];
        index2 += 1;
        }
    }
fclose(stream);
}

void get_enemy_coords()
{
char ch;
int end_flag=0;
int index;
int enemy_type;
int is_it_x;
string input;
string number;
FILE *stream;

string enemy_sprites_open_tokens[Q_ENEMY_TYPES]  = {"<bishop>", "<rook>", "<pawn>", "<knight>", "<queen>"};
string enemy_sprites_open_x_token = "x:";
string enemy_sprites_open_y_token = "y:";
string enemy_sprites_close_tokens[Q_ENEMY_TYPES] = {"</bishop>", "</rook>", "</pawn>", "</knight>", "</queen>"};
string eof_token = "<end>";
string delimeter = " ";

fopen_s(&stream, "enemy_coords.txt", "r");


q_enemyes = 0;

while(!end_flag)
    {
    ch = fgetc(stream);
    if(ch == '\n')
        {
        input+=delimeter;
        }
    else
        {
        input+=ch;
        }


    for(index=0; index<Q_ENEMY_TYPES; index++)
        {
        if(input.find(enemy_sprites_open_tokens[index]) != string::npos)
            {
            enemy_type = index;
            input = "";
            break;
            }
        }

    if(input.find(enemy_sprites_open_x_token) != string::npos)
        {
        input = "";
        is_it_x = 1;
        }

    if(input.find(enemy_sprites_open_y_token) != string::npos)
        {
        input = "";
        is_it_x = 0;
        }

    if(input.find(delimeter) != string::npos)
        {
        input.erase(input.length()-delimeter.length());
        number = input;
        if(number!="")
            {
            if(is_it_x == 1)
                {
                enemyes_x[q_enemyes] = stod(input);
                }
            else
                {
                enemyes_y[q_enemyes] = stod(input);
                enemyes_types[q_enemyes] = enemy_type;
                q_enemyes+=1;
                }
            }
        }

    if(input.find(eof_token) != string::npos)
        {
        end_flag=1;
        input = "";
        }
    }
}

void init_enemyes()
{
int index, index1, index2, index3, index4, temp;
string input;
char ch;
int end_flag=0, frame_index=0, body_index=0, enemy_frame_body_open_index=0;
FILE *stream;

string enemy_sprite_open_token = "<sprite_enemy>", enemy_sprite_close_token = "</sprite_enemy>",
       eof_token = "<end>", enemy_body_open_token = "<enemy_body>", enemy_body_close_token = "</enemy_body>",
       enemy_frame_body_open_token = "<visible_enemy>", enemy_frame_body_close_token = "</visible_enemy>";

fopen_s(&stream, "enemy_sprites.txt", "r");

for(index=0; index<q_enemyes; index++)
    {
    enemyes[index].enemy_type = enemyes_types[index];
    enemyes[index].x          = enemyes_x[index];
    enemyes[index].y          = enemyes_y[index];
    }


while(!end_flag)
    {
    ch = fgetc(stream);
    input += ch;
    if(input.find(enemy_sprite_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(enemy_sprite_close_token) != string::npos)
        {
        input.erase(input.length()-enemy_sprite_close_token.length());
        enemyes[0].frames[frame_index] = input;
        frame_index += 1;
        input = "";
        }

    if(input.find(enemy_body_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(enemy_body_close_token) != string::npos)
        {
        input.erase(input.length()-enemy_body_close_token.length());
        enemyes[0].body[body_index] = input;
        body_index += 1;
        input = "";
        }


    if(input.find(enemy_frame_body_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(enemy_frame_body_close_token) != string::npos)
        {
        input.erase(input.length()-enemy_frame_body_close_token.length());
        enemyes[0].visiably_part[enemy_frame_body_open_index] = input;
        enemy_frame_body_open_index += 1;
        input = "";
        }

    if(input.find(eof_token) != string::npos)
        {
        end_flag=1;
        input = "";
        }
    }

for(index=0; index<q_enemyes; index++)// copy frames to other
    {
    enemyes[index].clock = enemyes[index].first_bullet_clocks[enemyes[index].enemy_type];
    enemyes[index].frame_clock = 0;
    enemyes[index].num_frame  = 0;
    enemyes[index].state  = ENEMY_STATE_ALIVE;
    for(index1=0; index1<Q_ENEMY_FRAMES; index1++)
        {
        enemyes[index].body[index1]          = enemyes[0].body[index1];
        enemyes[index].visiably_part[index1] = enemyes[0].visiably_part[index1];
        enemyes[index].frames[index1]        = enemyes[0].frames[index1];
        }
    }

for(index=0; index<q_enemyes; index++)
    {
    enemyes[index].q_frames_in_animation[enemyes[index].enemy_type] -= enemyes[index].q_frames_in_animation[enemyes[index].enemy_type] %
                                                                         enemyes[index].q_indexes_of_frames_in_animation[enemyes[index].enemy_type];
    enemyes[index].states_q_frames[ENEMY_STATE_ALIVE] = enemyes[index].q_frames_in_animation[enemyes[index].enemy_type];
    index4=0;
    for(index1=0; index1<enemyes[index].q_indexes_of_frames_in_animation[enemyes[index].enemy_type]; index1++)
        {

        temp = enemyes[index].indexes_of_frames_in_animation[enemyes[index].enemy_type][index1];

        for(index3=0; index3<enemyes[index].q_frames_in_animation[enemyes[index].enemy_type]/
                                                                         enemyes[index].q_indexes_of_frames_in_animation[enemyes[index].enemy_type]; index3++)
            {
            enemyes[index].frames_for_states[enemyes[index].enemy_type][ENEMY_STATE_ALIVE][index4] = temp;
            index4+=1;
            }
        }
    }

for(index=0; index<q_enemyes; index++)
    {
    enemyes[index].q_frames_in_deing_animation[enemyes[index].enemy_type] -= enemyes[index].q_frames_in_deing_animation[enemyes[index].enemy_type] %
            enemyes[index].q_indexes_of_frames_in_deing_animation[enemyes[index].enemy_type];

    enemyes[index].states_q_frames[ENEMY_STATE_DIEING] = enemyes[index].q_frames_in_deing_animation[enemyes[index].enemy_type];
    index4=0;
    for(index1=0; index1<enemyes[index].q_indexes_of_frames_in_deing_animation[enemyes[index].enemy_type]; index1++)
        {

        temp = enemyes[index].indexes_of_frames_in_deing_animation[enemyes[index].enemy_type][index1];

        for(index3=0; index3<
            enemyes[index].q_frames_in_deing_animation[enemyes[index].enemy_type]/enemyes[index].q_indexes_of_frames_in_deing_animation[enemyes[index].enemy_type]; index3++)
            {
            enemyes[index].frames_for_states[enemyes[index].enemy_type][ENEMY_STATE_DIEING][index4] = temp;
            index4+=1;
            }
        }
    }

fclose(stream);
}

void init_bullets()
{
int index, index1, index2, index3, index4, temp;
string input;
char ch;
int end_flag=0, frame_index=0;
FILE *stream;

string bullet_sprite_open_token = "<sprite_bullet>", bullet_sprite_close_token = "</sprite_bullet>", eof_token = "<end>";

fopen_s(&stream, "bullets_sprites.txt", "r");

while(!end_flag)
    {
    ch = fgetc(stream);
    input += ch;
    if(input.find(bullet_sprite_open_token) != string::npos)
        {
        input = "";
        ch = fgetc(stream);
        if(ch!='\n')
            {
            input += ch;
            }
        }

    if(input.find(bullet_sprite_close_token) != string::npos)
        {
        input.erase(input.length()-bullet_sprite_close_token.length());
        bullets[0].frames[frame_index] = input;
        frame_index += 1;
        input = "";
        }

    if(input.find(eof_token) != string::npos)
        {
        end_flag=1;
        input = "";
        }
    }

for(index=1; index<Q_BULLETS; index++) // copy frames to other
    {
    for(index1=0; index1<Q_BULLET_FRAMES; index1++)
        {
        bullets[index].frames[index1] = bullets[0].frames[index1];
        }
    }

for(index=0; index<Q_BULLETS; index++)
    {
    bullets[index].clock = 0;
    bullets[index].clock_frame = 0;
    }

for(index=0; index<Q_BULLETS; index++)
    {
    bullets[index].q_frames_in_animation -= bullets[index].q_frames_in_animation%bullets[index].q_index_of_frames;
    index4=0;
    for(index1=0; index1<bullets[index].q_index_of_frames; index1++)
        {
        temp = bullets[index].indexes_of_frames[index1];

        for(index3=0; index3<bullets[index].q_frames_in_animation/bullets[index].q_index_of_frames; index3++)
            {
            bullets[index].frames_animation[index4] = temp;
            index4+=1;
            }
        }
    }
fclose(stream);
}

void change_bullets_states()
{
int index;
for(index=0; index<Q_BULLETS; index++)
    {
    if(bullets[index].clock>0)
        {
        bullets[index].clock-=1;
        bullets[index].clock_frame+=1;

        bullets[index].x += bullets[index].v_x;
        bullets[index].y += bullets[index].v_y;

        if(bullets[index].clock_frame >= bullets[index].q_frames_in_animation)
            {
            bullets[index].clock_frame = 0;
            }

        bullets[index].num_frame = bullets[index].frames_animation[bullets[index].clock_frame];
        }
    }
}

void create_bullet(double x, double y, double v_x, double v_y, int clock)
{
int index;
for(index=0; index<Q_BULLETS; index++)
    {
    if(bullets[index].clock == 0)
        {
        bullets[index].clock = clock;
        bullets[index].x     = x;
        bullets[index].y     = y;
        bullets[index].v_x   = v_x;
        bullets[index].v_y   = v_y;
        break;
        }
    }
}

void change_enemyes_states()
{
int index, flag_x, flag_y, i_x, i_y, i, flag_of_intersection;
int knight_frame_body_arr[main_knight.width][main_knight.heigth];
int enemy_frame_body_arr[MAX_ENEMY_WIDTH][MAX_ENEMY_HEIGTH];

// test is enemy dieing
for(index=0; index<q_enemyes; index++)
    {
    if(enemyes[index].state == ENEMY_STATE_ALIVE)
        {
        flag_x = 0;
        flag_y = 0;

        if((int)main_knight.x <= (int)enemyes[index].x)
            {
            if((int)enemyes[index].x - (int)main_knight.x < main_knight.body_width)
                {
                flag_x = 1;
                }
            }

        if((int)main_knight.x > (int)enemyes[index].x)
            {
            if((int)main_knight.x - (int)enemyes[index].x < enemyes[index].body_width)
                {
                flag_x = 1;
                }
            }

        if((int)main_knight.y <= (int)enemyes[index].y)
            {
            if((int)enemyes[index].y - (int)main_knight.y < main_knight.body_heigth)
                {
                flag_y = 1;
                }
            }

        if((int)main_knight.y > (int)enemyes[index].y)
            {
            if((int)main_knight.y - (int)enemyes[index].y < enemyes[index].body_heigth)
                {
                flag_y = 1;
                }
            }

        if(flag_x == 1 && flag_y == 1)
            {

            flag_of_intersection = 0;

            for(i_x=0; i_x<enemyes[index].body_width; i_x++)
                {
                for(i_y=0; i_y<enemyes[index].body_heigth; i_y++)
                    {
                    enemy_frame_body_arr[i_x][i_y]=0;
                    }
                }

            i_x=0;
            i_y=0;
            for(i=0; i<enemyes[index].body[enemyes[index].num_frame].length(); i++)
                {
                if(enemyes[index].body[enemyes[index].num_frame][i] == '\n')
                    {
                    i_y+=1;
                    i_x=-1;
                    }
                else if(enemyes[index].body[enemyes[index].num_frame][i] != ' ')
                    {
                    enemy_frame_body_arr[i_x][i_y]=1;
                    }
                i_x+=1;
                }

            // knight

            for(i_x=0; i_x<main_knight.body_width; i_x++)
                {
                for(i_y=0; i_y<main_knight.body_heigth; i_y++)
                    {
                    knight_frame_body_arr[i_x][i_y]=0;
                    }
                }

            i_x=0;
            i_y=0;
            for(i=0; i<main_knight.body[main_knight.num_frame].length(); i++)
                {
                if(main_knight.body[main_knight.num_frame][i] == '\n')
                    {
                    i_y+=1;
                    i_x=-1;
                    }
                else if(main_knight.body[main_knight.num_frame][i] != ' ')
                    {
                    knight_frame_body_arr[i_x][i_y]=1;
                    }
                i_x+=1;
                }

            // test
            for(i_x=max((int)main_knight.x, (int)enemyes[index].x); i_x<min((int)main_knight.x+main_knight.body_width,
                                                                  (int)enemyes[index].x+enemyes[index].body_width); i_x++)
                {
                for(i_y=max((int)main_knight.y, (int)enemyes[index].y); i_y<min((int)main_knight.y+main_knight.body_heigth,
                                                                            (int)enemyes[index].y+enemyes[index].body_heigth); i_y++)
                    {
                    if(knight_frame_body_arr[i_x-(int)main_knight.x][i_y-(int)main_knight.y] == 1 &&
                       enemy_frame_body_arr[i_x-(int)enemyes[index].x][i_y-(int)enemyes[index].y] == 1)
                        {
                        flag_of_intersection  = 1;
                        }
                    }
                }

            if(flag_of_intersection == 1)
                {
                enemyes[index].state = ENEMY_STATE_DIEING;
                enemyes[index].clock = 0;
                enemyes[index].frame_clock = 0;
                enemyes[index].dieing_x = (int)(enemyes[index].x + enemyes[index].width/2);
                enemyes[index].dieing_y = (int)(enemyes[index].y + enemyes[index].heigth/2);
                }
            }
        }
    }
// end of test

for(index=0; index<q_enemyes; index++)
    {
    if(enemyes[index].state != ENEMY_STATE_DIE)
        {
        enemyes[index].num_frame = enemyes[index].frames_for_states[enemyes[index].enemy_type][enemyes[index].state][enemyes[index].frame_clock];

        if(enemyes[index].state == ENEMY_STATE_DIEING)
            {
            enemyes[index].x = (int)(enemyes[index].dieing_x - (enemyes[index].width)/2);
            enemyes[index].y = (int)(enemyes[index].dieing_y - (enemyes[index].heigth)/2);
            }

        enemyes[index].clock+=1;
        enemyes[index].frame_clock+=1;

        if(enemyes[index].frame_clock >= enemyes[index].states_q_frames[enemyes[index].state])
            {
            enemyes[index].frame_clock = 0;
            if(enemyes[index].state == ENEMY_STATE_DIEING)
                {
                enemyes[index].state = ENEMY_STATE_DIE;
                }
            }

        if(enemyes[index].clock >= enemyes[index].clock_to_fire[enemyes[index].enemy_type] &&
           enemyes[index].state == ENEMY_STATE_ALIVE)
            {
            enemyes[index].clock=0;
            create_bullet(enemyes[index].x+enemyes[index].bullet_x_offset[enemyes[index].enemy_type],
                          enemyes[index].y+enemyes[index].bullet_y_offset[enemyes[index].enemy_type],
                          enemyes[index].bullet_v_x[enemyes[index].enemy_type], enemyes[index].bullet_v_y[enemyes[index].enemy_type],
                          enemyes[index].bullets_clock[enemyes[index].enemy_type]);
            }
        }
    }
}

void get_enemyes_parameters()
{
int index;
int i_x, i_y, i, max_x;
for(index=0; index<q_enemyes; index++)
    {
    i_y=0;
    i_x=0;
    max_x=-1;

    for(i=0; i<enemyes[index].frames[enemyes[index].num_frame].length(); i++)
        {
        i_x+=1;
        if(enemyes[index].frames[enemyes[index].num_frame][i] == '\n')
            {
            i_y+=1;
            if(max_x<i_x)
                {
                max_x=i_x;
                }
            i_x=0;
            }
        }

    enemyes[index].old_width     = enemyes[index].width;
    enemyes[index].old_heigth    = enemyes[index].heigth;

    enemyes[index].width     = max_x-1;
    enemyes[index].heigth    = i_y;

    i_y=0;
    i_x=0;
    max_x=-1;

    for(i=0; i<enemyes[index].body[enemyes[index].num_frame].length(); i++)
        {
        i_x+=1;
        if(enemyes[index].body[enemyes[index].num_frame][i] == '\n')
            {
            i_y+=1;
            if(max_x<i_x)
                {
                max_x=i_x;
                }
            i_x=0;
            }
        }

    enemyes[index].body_width     = max_x-1;
    enemyes[index].body_heigth    = i_y;
    }
}

void try_set_pixel_to_screen(int x, int y, char color)
{
if(x>=0 && x<SCREEN_WIDTH && y>=0 && y<SCREEN_HEIGTH)
    {
    screen[x][y] = color;
    }
}

void test_knight_state()
{
int index, i_x, i_y, i;

if(main_knight.state == K_STATE_DEAD || main_knight.state == K_STATE_DIYING)
    {
    return;
    }

int knight_body_arr[main_knight.body_width][main_knight.body_heigth];

for(i_x=0; i_x<main_knight.body_width; i_x++)
    {
    for(i_y=0; i_y<main_knight.body_heigth; i_y++)
        {
        knight_body_arr[i_x][i_y]=0;
        }
    }

i_x=0;
i_y=0;

for(i=0; i<main_knight.body[main_knight.num_frame].length(); i++)
    {
    if(main_knight.body[main_knight.num_frame][i] == '\n')
        {
        i_y+=1;
        i_x=-1;
        }
    else if(main_knight.body[main_knight.num_frame][i] != ' ')
        {
        knight_body_arr[i_x][i_y]=1;
        }
    i_x+=1;
    }

for(index=0; index<Q_BULLETS; index++)
    {
    if(bullets[index].clock > 0)
        {
        if((int)bullets[index].x - (int)main_knight.x >=0 && (int)bullets[index].x - (int)main_knight.x < main_knight.body_width &&
           (int)bullets[index].y - (int)main_knight.y >=0 && (int)bullets[index].y - (int)main_knight.y < main_knight.body_heigth)
            {
            if(knight_body_arr[(int)bullets[index].x - (int)main_knight.x][(int)bullets[index].y - (int)main_knight.y] == 1)
                {
                main_knight.state = K_STATE_DIYING;
                main_knight.state_clock = 0;
                main_knight.dieing_x = (int)(main_knight.x + main_knight.body_width/2);
                main_knight.dieing_y = (int)(main_knight.y + main_knight.body_heigth/2);
                break;
                }
            }
        }
    }
}

char try_get_pixel_from_screen(int x, int y)
{
if(x>=0 && x<SCREEN_WIDTH && y>=0 && y<SCREEN_HEIGTH)
    {
    return(screen[x][y]);
    }
return(' ');
}

void get_screen(int l_up_x, int l_up_y)
{
int i_x, i_y, i, index;
int knight_frame_body_arr[MAX_KNIGHT_WIDTH][MAX_KNIGHT_HEIGTH];
int enemy_frame_body_arr[MAX_ENEMY_WIDTH][MAX_ENEMY_HEIGTH];
int bullet_frame_body_arr[MAX_ENEMY_WIDTH][MAX_ENEMY_HEIGTH];
// layers
for(i_x=0; i_x<SCREEN_WIDTH; i_x++)
    {
    for(i_y=0; i_y<SCREEN_HEIGTH; i_y++)
        {

        screen[i_x][i_y] = ' ';
        screen[i_x][i_y] = get_pixel_from_layers(l_up_x, l_up_y, i_x, i_y);
        if(i_x+l_up_x<MAP_WIDTH && i_x+l_up_x>=0 && i_y+l_up_y<MAP_HEIGTH && i_y+l_up_y>=0)
            {
            if(_map[i_y+l_up_y][i_x+l_up_x] != ' ')
                {
                screen[i_x][i_y] = _map[i_y+l_up_y][i_x+l_up_x];
                }
            }
        else
            {
            screen[i_x][i_y] = ' ';
            }
        }
    }

// enemy

for(index=0; index<q_enemyes; index++)
    {
    if((((int)enemyes[index].x - l_up_x)<=SCREEN_WIDTH && ((int)enemyes[index].x + enemyes[index].width - l_up_x) >= 0)
       && (((int)enemyes[index].y - l_up_y)<=SCREEN_HEIGTH && ((int)enemyes[index].y + enemyes[index].heigth - l_up_y) >= 0)
       && enemyes[index].state != ENEMY_STATE_DIE)
        {
        for(i_x=0; i_x<enemyes[index].width; i_x++)
            {
            for(i_y=0; i_y<enemyes[index].heigth; i_y++)
                {
                enemy_frame_body_arr[i_x][i_y]=0;
                }
            }

        i_x=0;
        i_y=0;
        for(i=0; i<enemyes[index].visiably_part[enemyes[index].num_frame].length(); i++)
            {
            if(enemyes[index].visiably_part[enemyes[index].num_frame][i] == '\n')
                {
                i_y+=1;
                i_x=-1;
                }
            else if(enemyes[index].visiably_part[enemyes[index].num_frame][i] != ' ')
                {
                enemy_frame_body_arr[i_x][i_y]=1;
                }
            i_x+=1;
            }


        i_x = (int)enemyes[index].x - l_up_x;
        i_y = (int)enemyes[index].y - l_up_y;

        for(i=0; i<enemyes[index].frames[enemyes[index].num_frame].length(); i++)
            {
            if(enemyes[index].frames[enemyes[index].num_frame][i] == '\n')
                {
                i_y += 1;
                i_x = (int)enemyes[index].x - l_up_x;
                }
            else
                {
                if(enemy_frame_body_arr[i_x-((int)enemyes[index].x - l_up_x)][i_y-((int)enemyes[index].y - l_up_y)] == 1
                   || try_get_pixel_from_screen(i_x, i_y) == ' ')
                    {
                    try_set_pixel_to_screen(i_x, i_y, enemyes[index].frames[enemyes[index].num_frame][i]);
                    }
                i_x += 1;
                }
            }
        }
    }

// knight

for(i_x=0; i_x<main_knight.width; i_x++)
    {
    for(i_y=0; i_y<main_knight.heigth; i_y++)
        {
        knight_frame_body_arr[i_x][i_y]=0;
        }
    }

i_x=0;
i_y=0;
for(i=0; i<main_knight.visiably_part[main_knight.num_frame].length(); i++)
    {
    if(main_knight.visiably_part[main_knight.num_frame][i] == '\n')
        {
        i_y+=1;
        i_x=-1;
        }
    else if(main_knight.visiably_part[main_knight.num_frame][i] != ' ')
        {
        knight_frame_body_arr[i_x][i_y]=1;
        }
    i_x+=1;
    }

main_knight.scr_off_x = (int)main_knight.x - l_up_x;
main_knight.scr_off_y = (int)main_knight.y - l_up_y;

i_y = main_knight.scr_off_y;
i_x = main_knight.scr_off_x;
for(i=0; i<main_knight.frames[main_knight.num_frame].length(); i++)
    {
    if(main_knight.frames[main_knight.num_frame][i] == '\n')
        {
        i_y += 1;
        i_x = main_knight.scr_off_x;
        }
    else
        {
        if(knight_frame_body_arr[i_x-main_knight.scr_off_x][i_y-main_knight.scr_off_y] == 1 || screen[i_x][i_y] == ' ')
            {
            screen[i_x][i_y] = main_knight.frames[main_knight.num_frame][i];
            }
        i_x += 1;
        }
    }

// bullets

for(index=0; index<Q_BULLETS; index++)
    {
    if(bullets[index].clock>0)
        {
        i_x = (int)bullets[index].x - l_up_x;
        i_y = (int)bullets[index].y - l_up_y;

        for(i=0; i<bullets[index].frames[bullets[index].num_frame].length(); i++)
            {
            if(bullets[index].frames[bullets[index].num_frame][i] == '\n')
                {
                i_y += 1;
                i_x = (int)bullets[index].x - l_up_x;
                }
            else
                {
                try_set_pixel_to_screen(i_x, i_y, bullets[index].frames[bullets[index].num_frame][i]);
                i_x += 1;
                }
            }
        }
    }

// labels


if(main_knight.state == K_STATE_DEAD)
    {
    draw_lose_label();
    if(main_knight.state_clock%100 == 0)
        {
        redraw_lose_label();
        }
    }

if(win_index<Q_ITERATIONS_IF_WIN)
    {
    draw_win_label();
    if(win_index%100 == 0)
        {
        redraw_win_label();
        }
    }
}

void get_knight_parameters()
{
int i_x, i_y, i, max_x;

i_y=0;
i_x=0;
max_x=-1;
for(i=0; i<main_knight.frames[main_knight.num_frame].length(); i++)
    {
    i_x+=1;
    if(main_knight.frames[main_knight.num_frame][i] == '\n')
        {
        i_y+=1;
        if(max_x<i_x)
            {
            max_x=i_x;
            }
        i_x=0;
        }
    }


main_knight.width      = max_x-1;
main_knight.heigth     = i_y;

if(main_knight.flag_to_move_screen_by_width_and_heigth[main_knight.num_frame] == 1)
    {
    main_knight.scr_off_x = SCREEN_WIDTH/2 - main_knight.width/2;
    main_knight.scr_off_y = SCREEN_HEIGTH/2 - main_knight.heigth/2;
    }


i_y=0;
i_x=0;
max_x=-1;
for(i=0; i<main_knight.body[main_knight.num_frame].length(); i++)
    {
    i_x+=1;
    if(main_knight.body[main_knight.num_frame][i] == '\n')
        {
        i_y+=1;
        if(max_x<i_x)
            {
            max_x=i_x;
            }
        i_x=0;
        }
    }

main_knight.body_width     = max_x-1;
main_knight.body_heigth    = i_y;
}

void knight_diying_animation()
{
if(main_knight.state == K_STATE_DIYING)
    {
    main_knight.x = (int)(main_knight.dieing_x - (main_knight.width)/2);
    main_knight.y = (int)(main_knight.dieing_y - (main_knight.heigth)/2);
    }

main_knight.old_width  = main_knight.width;
main_knight.old_heigth = main_knight.heigth;
}

bool is_knight_crashed_into_map()
{
int i_x, i_y, i;
int knight_body_arr[main_knight.body_width][main_knight.body_heigth];

for(i_x=0; i_x<main_knight.body_width; i_x++)
    {
    for(i_y=0; i_y<main_knight.body_heigth; i_y++)
        {
        knight_body_arr[i_x][i_y]=0;
        }
    }

i_x=0;
i_y=0;
for(i=0; i<main_knight.body[main_knight.num_frame].length(); i++)
    {
    if(main_knight.body[main_knight.num_frame][i] == '\n')
        {
        i_y+=1;
        i_x=-1;
        }
    else if(main_knight.body[main_knight.num_frame][i] == '1')
        {
        knight_body_arr[i_x][i_y]=1;
        }
    i_x+=1;
    }

for(i_x=0; i_x<main_knight.body_width; i_x++)
    {
    i_y=main_knight.body_heigth-1;
        {
        if(_map[(int)main_knight.y+i_y][(int)main_knight.x+i_x]!=' ' && knight_body_arr[i_x][i_y]==1)
            {
            return true;
            }
        }
    }

return false;
}

bool is_knight_falling()
{
int i_x, i_y, i;
int knight_body_arr[main_knight.body_width][main_knight.body_heigth];

for(i_x=0; i_x<main_knight.body_width; i_x++)
    {
    for(i_y=0; i_y<main_knight.body_heigth; i_y++)
        {
        knight_body_arr[i_x][i_y]=0;
        }
    }

i_x=0;
i_y=0;
for(i=0; i<main_knight.body[main_knight.num_frame].length(); i++)
    {
    if(main_knight.body[main_knight.num_frame][i] == '\n')
        {
        i_y+=1;
        i_x=-1;
        }
    else if(main_knight.body[main_knight.num_frame][i] == '1')
        {
        knight_body_arr[i_x][i_y]=1;
        }
    i_x+=1;
    }

for(i_x=0; i_x<main_knight.body_width; i_x++)
    {
    i_y=main_knight.body_heigth-1;
        {
        if(_map[(int)main_knight.y+i_y+1][(int)main_knight.x+i_x]!=' ' && knight_body_arr[i_x][i_y]==1)
            {
            return false;
            }
        }
    }

return true;
}

void try_dec_win_index()
{
int index, flag;
flag=1;
for(index=0; index<q_enemyes; index++)
    {
    if(enemyes[index].state != ENEMY_STATE_DIE)
        {
        flag = 0;
        }
    }

for(index=0; index<Q_BULLETS; index++)
    {
    if(bullets[index].clock > 0)
        {
        flag = 0;
        }
    }

if(flag == 1)
    {
    win_index-=1;
    }
}


void init_console()
{
string s;

s="mode con cols=";
s+=to_string(SCREEN_WIDTH);
s+=" lines=";
s+=to_string(SCREEN_HEIGTH+1); // for last endl

system(s.c_str());
}

void return_knight_into_map(double add_x, double add_y)
{
    while((int)main_knight.x<1)
        {
        main_knight.x-=add_x;
        }

    while((int)main_knight.x>=MAP_WIDTH-main_knight.width)
        {
        main_knight.x-=add_x;
        }

    while((int)main_knight.y<0)
        {
        main_knight.y-=add_y;
        }

    while((int)main_knight.y>=MAP_HEIGTH-main_knight.heigth)
        {
        main_knight.y-=add_y;
        }
}

void main2()
{

_window_cmd(WINDOW_VGA_HIDE);

int scr_x=0, scr_y=0;
int landing_knight_state = K_STATE_WATCH_RIGHT;
int right_key_pressed, left_key_pressed, up_key_pressed;
int index;

Blinking();
init_keybuff();
init_console();

start:

G_S = G_S_PLAYING;
init_screensavers();



for(index=0; index<q_screensavers; index++)
    {
    while(_screensaver[index].clock_to_dissapear >= 0)
        {
        _screensaver[index].clock_to_dissapear -= 1;
        _screensaver[index].clock+=1;
        if(_screensaver[index].clock >= _screensaver[index].q_ticks_to_animate)
            {
            _screensaver[index].clock = 0;
            get_screensaver(index);
            }
        move_screensaver_to_screen(index);
        draw_screen();
        }
    }



init_layers();
init_map();
get_enemy_coords();
init_enemyes();
init_bullets();
init_lose_label();
init_win_label();

init_main_knight();

get_knight_parameters();
get_enemyes_parameters();

scr_x = (int)main_knight.x - main_knight.scr_off_x;
scr_y = (int)main_knight.y - main_knight.scr_off_y;


/*for(int ch=-127; ch<128; ch++)
    {
    cout  << ch << (char)ch << endl;
    }
return;*/

/*cout << main_knight.frames[12];
return;*/


while(G_S == G_S_PLAYING)
    {
    right_key_pressed = 0;
    left_key_pressed  = 0;
    up_key_pressed    = 0;

    get_knight_parameters();

// key pressing ////////////////////////////////////////
	if(key_table[INDEX_RIGHT])
		{
        right_key_pressed = 1;
		}
    if(key_table[INDEX_LEFT])
        {
        left_key_pressed = 1;
        }
    if(key_table[INDEX_UP])
        {
        up_key_pressed = 1;
        }
    if(key_table[INDEX_DOWN])
        {
        }
// end of key pressing ////////////////////////////////////////

    if(right_key_pressed == 1 && left_key_pressed == 1)
        {
        right_key_pressed = 0;
        left_key_pressed  = 0;
        }

    if(is_knight_falling() && main_knight.state != K_STATE_JUMP_UP
       && main_knight.state != K_STATE_JUMP_DOWN && main_knight.state != K_STATE_DEAD
       && main_knight.state != K_STATE_DIYING)
        {
        main_knight.state = K_STATE_JUMP_DOWN;
        main_knight.state_clock = 0;
        }

    switch(main_knight.state)
        {
        case K_STATE_RUN_RIGHT:
            {
            landing_knight_state = K_STATE_WATCH_RIGHT;
            if(left_key_pressed == 0 && up_key_pressed ==0 && right_key_pressed==0)
                {
                main_knight.state = K_STATE_WATCH_RIGHT;
                main_knight.state_clock = 0;
                }
            else if(left_key_pressed == 1 && up_key_pressed ==0)
                {
                main_knight.state = K_STATE_RUN_LEFT;
                main_knight.state_clock = 0;
                }
            else if(up_key_pressed ==1)
                {
                main_knight.state = K_STATE_JUMP_UP;
                main_knight.state_clock = 0;
                }
            else
                {
                main_knight.x+=0.03;
                if(is_knight_crashed_into_map())
                    {
                    main_knight.x-=0.03;
                    main_knight.state = K_STATE_WATCH_RIGHT;
                    main_knight.state_clock = 0;
                    }
                }
            } break;

        case K_STATE_RUN_LEFT:
            {
            landing_knight_state = K_STATE_WATCH_LEFT;
            if(left_key_pressed == 0 && up_key_pressed ==0 && right_key_pressed==0)
                {
                main_knight.state = K_STATE_WATCH_LEFT;
                main_knight.state_clock = 0;
                }
            else if(right_key_pressed == 1 && up_key_pressed ==0)
                {
                main_knight.state = K_STATE_RUN_RIGHT;
                main_knight.state_clock = 0;
                }
            else if(up_key_pressed ==1)
                {
                main_knight.state = K_STATE_JUMP_UP;
                main_knight.state_clock = 0;
                }
            else
                {
                main_knight.x-=0.03;
                if(is_knight_crashed_into_map())
                    {
                    main_knight.x+=0.03;
                    main_knight.state = K_STATE_WATCH_LEFT;
                    main_knight.state_clock = 0;
                    }
                }
            } break;

        case K_STATE_WATCH_RIGHT:
            {
            if(left_key_pressed == 1 && up_key_pressed == 0)
                {
                main_knight.state = K_STATE_RUN_LEFT;
                main_knight.state_clock = 0;
                }
            else if(right_key_pressed == 1 && up_key_pressed == 0)
                {
                main_knight.state = K_STATE_RUN_RIGHT;
                main_knight.state_clock = 0;

                main_knight.x+=0.05;
                if(is_knight_crashed_into_map())
                    {
                    main_knight.x-=0.05;
                    main_knight.state = K_STATE_WATCH_RIGHT;
                    main_knight.state_clock = 0;
                    }
                }
            else if(up_key_pressed ==1)
                {
                main_knight.state = K_STATE_JUMP_UP;
                main_knight.state_clock = 0;
                }
            } break;

        case K_STATE_WATCH_LEFT:
            {
            if(left_key_pressed == 0 && up_key_pressed ==0 && right_key_pressed==0)
                {
                main_knight.state = K_STATE_WATCH_LEFT;
                main_knight.state_clock = 0;
                }
            else if(right_key_pressed == 1 && up_key_pressed ==0)
                {
                main_knight.state = K_STATE_RUN_RIGHT;
                main_knight.state_clock = 0;
                }
            else if(left_key_pressed == 1 && up_key_pressed ==0)
                {
                main_knight.state = K_STATE_RUN_LEFT;
                main_knight.state_clock = 0;

                main_knight.x-=0.05;
                if(is_knight_crashed_into_map())
                    {
                    main_knight.x+=0.05;
                    main_knight.state = K_STATE_WATCH_LEFT;
                    main_knight.state_clock = 0;
                    }
                }
            else if(up_key_pressed ==1)
                {
                main_knight.state = K_STATE_JUMP_UP;
                main_knight.state_clock = 0;
                }
            } break;

        case K_STATE_JUMP_DOWN:
            {
            if(left_key_pressed == 0 && right_key_pressed == 0)
                {
                main_knight.y+=0.01;
                if(is_knight_crashed_into_map())
                    {
                    main_knight.y-=0.01;
                    main_knight.state = landing_knight_state;
                    main_knight.state_clock = 0;
                    }
                }
            else if(left_key_pressed == 1)
                {
                landing_knight_state = K_STATE_WATCH_LEFT;
                main_knight.x-=0.03;
                main_knight.y+=0.01;

                if(is_knight_crashed_into_map())
                    {
                    main_knight.x+=0.03;
                    if(is_knight_crashed_into_map())
                        {
                        main_knight.y-=0.01;
                        main_knight.state = K_STATE_WATCH_RIGHT;
                        main_knight.state_clock = 0;
                        }
                    }
                }
            else if(right_key_pressed == 1)
                {
                landing_knight_state = K_STATE_WATCH_RIGHT;
                main_knight.x+=0.03;
                main_knight.y+=0.01;

                if(is_knight_crashed_into_map())
                    {
                    main_knight.x-=0.03;
                    if(is_knight_crashed_into_map())
                        {
                        main_knight.y-=0.01;
                        main_knight.state = K_STATE_WATCH_RIGHT;
                        main_knight.state_clock = 0;
                        }
                    }
                }
            } break;

        case K_STATE_JUMP_UP:
            {
            if(left_key_pressed == 0 && right_key_pressed == 0)
                {
                main_knight.y-=0.01;
                return_knight_into_map(0, -0.01);
                main_knight.jump_up_table_index+=1;
                if(main_knight.jump_up_table_index >= Q_JUMP_UP_ADDS)
                    {
                    while(is_knight_crashed_into_map())
                        {
                        main_knight.y+=0.01;
                        }
                    main_knight.state = K_STATE_JUMP_DOWN;
                    main_knight.state_clock = 0;
                    main_knight.jump_up_table_index = 0;
                    }
                }
            else if(left_key_pressed == 1)
                {
                landing_knight_state = K_STATE_WATCH_LEFT;
                main_knight.x-=0.03;
                main_knight.y-=0.01;
                return_knight_into_map(-0.03, -0.01);
                main_knight.jump_up_table_index+=1;
                if(main_knight.jump_up_table_index >= Q_JUMP_UP_ADDS)
                    {
                    while(is_knight_crashed_into_map())
                        {
                        main_knight.y+=0.01;
                        }
                    main_knight.state = K_STATE_JUMP_DOWN;
                    main_knight.state_clock = 0;
                    main_knight.jump_up_table_index = 0;
                    }
                }
            else if(right_key_pressed == 1)
                {
                landing_knight_state = K_STATE_WATCH_RIGHT;
                main_knight.x+=0.03;
                main_knight.y-=0.01;
                return_knight_into_map(0.03, -0.01);
                main_knight.jump_up_table_index+=1;
                if(main_knight.jump_up_table_index >= Q_JUMP_UP_ADDS)
                    {
                    while(is_knight_crashed_into_map())
                        {
                        main_knight.y+=0.01;
                        }
                    main_knight.state = K_STATE_JUMP_DOWN;
                    main_knight.state_clock = 0;
                    main_knight.jump_up_table_index = 0;
                    }
                }
            } break;

        case K_STATE_DIYING:
            {
            knight_diying_animation();
            } break;

        case K_STATE_DEAD:
            {

            } break;
        }

    if(main_knight.state != K_STATE_DEAD)
        {
        main_knight.num_frame = main_knight.frames_for_states[main_knight.state][main_knight.state_clock];
        }
    else
        {
        main_knight.num_frame = main_knight.frames_for_states[main_knight.state][0];
        }


    main_knight.state_clock += 1;

    get_knight_parameters();
    get_enemyes_parameters();

    test_knight_state();

    if(main_knight.state_clock >= main_knight.states_q_frames[main_knight.state])
        {
        if(main_knight.state == K_STATE_DIYING)
            {
            main_knight.state = K_STATE_DEAD;
            }
        else if(main_knight.state == K_STATE_DEAD)
            {
            G_S = G_S_LOSE;
            }
        main_knight.state_clock = 0;
        }

    try_dec_win_index();
    if(win_index==0)
        {
        G_S = G_S_WIN;
        }

    if((int)main_knight.x - scr_x > 2*SCREEN_WIDTH/3)
        {
        scr_x+=1;
        }

    if((int)main_knight.x - scr_x < SCREEN_WIDTH/3)
        {
        scr_x-=1;
        }

    if((int)main_knight.y - scr_y > 2*SCREEN_HEIGTH/3)
        {
        scr_y+=1;
        }

    if((int)main_knight.y - scr_y < SCREEN_HEIGTH/3)
        {
        scr_y-=1;
        }

    change_layers_state();
    change_enemyes_states();
    change_bullets_states();
    get_screen(scr_x, scr_y);
    draw_screen();
    }
goto start;
}
