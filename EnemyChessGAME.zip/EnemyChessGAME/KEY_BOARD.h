//------------------------------------------
// DOS DEVELOPMENT ENVIRONMENT EMULATION TOOLKIT
//------------------------------------------
#include "stdafx.h"
#include "DOSEmu.h"
//#include "graph0.h"
//------------------------------------------


// I N C L U D E S ///////////////////////////////////////////////////////////
#include <iostream>
#include <io.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
//#include <bios.h>
#include <fcntl.h>
#include <memory.h>
#include <malloc.h>
#include <math.h>
#include <string.h>

// DEFENITIONS /////////////////////////////////////////////////////////////////////

#define KEYBOARD_INT 0x09
#define KEY_BUFFER   0x60
#define KEY_CONTROL  0x61
#define INT_CONTROL  0x20

#define MAKE_RIGHT   103
#define MAKE_LEFT    101
#define MAKE_UP      100
#define MAKE_DOWN    102

#define MAKE_SPACE   57


#define BREAK_RIGHT  231
#define BREAK_LEFT   229
#define BREAK_UP     228
#define BREAK_DOWN   230

#define BREAK_SPACE  185

#define INDEX_UP     0
#define INDEX_DOWN   1
#define INDEX_RIGHT  2
#define INDEX_LEFT   3
#define INDEX_SPACE  4

// GLOBAL VARIABLES //////////////////////////////////////////////////////////////////

void (_interrupt _far *Old_Isr) ();

int raw_key;

int key_table[5] = {0, 0, 0, 0, 0};


// FUNCTIONS /////////////////////////////////////////////////////////////////////////

void _interrupt _far New_Key_Int()
{

raw_key = (unsigned)_inp(KEY_BUFFER);
switch(raw_key)
	{

	case MAKE_UP:
		{
		key_table[INDEX_UP]    = 1;
		} break;

	case MAKE_DOWN:
		{
		key_table[INDEX_DOWN]  = 1;
		} break;

	case MAKE_RIGHT:
		{
		key_table[INDEX_RIGHT] = 1;
		} break;

	case MAKE_LEFT:
		{
		key_table[INDEX_LEFT]  = 1;
		} break;

	case MAKE_SPACE:
		{
		key_table[INDEX_SPACE] = 1;
		} break;

	case BREAK_UP:
		{
		key_table[INDEX_UP]    = 0;
		} break;

	case BREAK_DOWN:
		{
		key_table[INDEX_DOWN]  = 0;
		} break;

	case BREAK_RIGHT:
		{
		key_table[INDEX_RIGHT] = 0;
		} break;

	case BREAK_LEFT:
		{
		key_table[INDEX_LEFT]  = 0;
		} break;

	case BREAK_SPACE:
		{
		key_table[INDEX_SPACE] = 0;
		} break;

		default:break;
	}
}

void init_keybuff()
{
Old_Isr = _dos_getvect(KEYBOARD_INT);
_dos_setvect(KEYBOARD_INT, (void *)New_Key_Int);
}





