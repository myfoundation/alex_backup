// LIBRARIES ////////

#include <windows.h>
#include "my_num_lib.h"
#include "code_generation.h"
#include <stdlib.h>
#include <iomanip>
#include <conio.h>

// DOC //////////////

/*
INT_16 BIOS INTERRUPT DOC

Push command and argumets to stack and call int_16.

1. COMMAND 0. Clear Screen

	#push(+0.0);
	#int_16();

2. COMMAND 1. Console cursor goto X,Y

		#push(x);
		#push(y);
		#push(+1.0);
		#int_16();

3. COMMAND 2. Beep Frequency, Time

		#push(freq);
		#push(time);
		#push(+2.0);
		#int_16();

4. COMMAND 3. Sleep Time

		#push(time);
		#push(+3.0);
		#int_16();

*/

/////////////////////

// DEFENITIONS //////

#define Q_ELEMS_IN_STACK 1000000
#define MAX_Q_COMMANDS   1000000
#define Q_OPERATIONS     36
#define Q_RETURN_CODES   6

#define UNKNOWN_OFFSET   0

//#define DEBUG_ON 1

/////////////////////

// NAMESPACE ////////

using namespace std;

enum vm_commands_indexes {OP_ADD = 0, OP_MIN, OP_MULT, OP_DIV,
                          OP_JMP, OP_JMP_IF_ZERO, OP_UNAR_MIN,
                          OP_POP, OP_PUSH, OP_CALL, OP_RET, OP_LOAD_VAR_BY_COMMAND,
                          OP_LOAD_VAR_BY_TOP_STACK, OP_WRITE_TO_VAR_BY_COMMAND,
                          OP_WRITE_TO_VAR_BY_TOP_STACK, OP_LOAD_ARG_BY_COMMAND,
                          OP_LOAD_ARG_BY_TOP_STACK, OP_WRITE_TO_ARG_BY_COMMAND,
                          OP_WRITE_TO_ARG_BY_TOP_STACK, OP_HALT, OP_BIGGER_OR_EQUAL,
                          OP_LESS_OR_EQUAL, OP_EQUAL, OP_NOT_EQUAL, OP_BIGGER, OP_LESS,
                          OP_LOGIC_TILDA, OP_LOAD_POINTER_TO_VAR_BY_TOP_STACK,
                          OP_LOAD_POINTER_TO_ARG_BY_TOP_STACK, OP_WRITE_BY_TOP_STACK,
                          OP_LOAD_POINTER_TO_VAR_BY_COMMAND, OP_LOAD_POINTER_TO_ARG_BY_COMMAND,
                          OP_WRITELN_TOP_STACK, OP_WRITE_CHAR_TOP_STACK, OP_LOAD_BY_TOP_STACK,
                          INT_16};

enum vm_return_codes {ALL_OK = 0, ERR_OF_DIV_BY_ZERO, ERR_OF_STACK_OVERFLOW, ERR_OF_UNKNOWN_OP,
                      ERR_OF_SP_MINUS_ONE, ERR_OF_GMP, ERR_UNKNOWN_INT};

string vm_commands[Q_OPERATIONS] = {"+", "-", "*", "/", "jmp", "jmp_if_zero",
                                    "un_-", "pop", "push", "call", "return", "load_var_by_command",
                                    "load_var_by_top_stack", "write_to_var_by_command",
                                    "write_to_var_by_top_stack", "load_arg_by_command",
                                    "load_arg_by_top_stack", "write_to_arg_by_command",
                                    "write_to_arg_by_top_stack", "halt", ">=", "<=", "==", "!=",
                                    ">", "<", "!", "load_pointer_to_var_by_top_stack",
                                    "load_pointer_to_arg_by_top_stack",
                                    "write_by_top_stack", "load_pointer_to_var_by_command",
                                    "load_pointer_to_arg_by_command", "writeln_top_stack",
                                    "write_char_top_stack", "load_by_top_stack", "int_16"};

int vm_vommands_stack_offsets[Q_OPERATIONS] = {-2, -2, -2, -2, 0, -1, -1, -1, 1,
                                               UNKNOWN_OFFSET, UNKNOWN_OFFSET, 1, 0, -1, -2, 1,
                                               0, -1, -2, 0, -2, -2, -2, -2, -2, -2, -1, -1, -1,
                                               -2, -1, -1, -1, -1, -1, -2};

MY_NUM _stack[Q_ELEMS_IN_STACK];
MY_NUM command_arr[MAX_Q_COMMANDS];

void show_vm_state(int sp, int cp);

void goto_for_cursor(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

int run_vm()
{
    int stack_pointer=-1, command_pointer, frame_pointer = -1, q_argvs = 0, q_vars = 0;
       // stack_pointer - index of last elem in stack

    int index_of_operation_now, index;
    MY_NUM temp1;
    int temp, temp2=0;

    for(command_pointer=0; command_pointer<MAX_Q_COMMANDS; command_pointer+=1)
    {
        /*if(command_pointer == 613)
        {
            temp2=1;
        }
        if(temp2==1)
        {
            cin >> temp;
            show_vm_state(stack_pointer, command_pointer);
        }*/

#ifdef DEBUG_ON
		getch();
		show_vm_state(stack_pointer, command_pointer);
#endif

        if((command_pointer<0) || (command_pointer>=MAX_Q_COMMANDS))
        {
            return(ERR_OF_GMP);
        }

        for(index_of_operation_now=0; index_of_operation_now<Q_OPERATIONS; index_of_operation_now++)
        {
            if(vm_commands[index_of_operation_now] == command_arr[command_pointer])
            {
                break;
            }
        }

        if(index_of_operation_now == Q_OPERATIONS)
        {
            cout << "--------------------------" << endl;
            cout << command_arr[command_pointer] << endl;
            cout << "load_pointer_to_var_by_command" << endl;
            cout << (int)(command_arr[command_pointer] == "load_pointer_to_var_by_command") << endl;
            cout << (int)(command_arr[command_pointer] == vm_commands[30]) << endl;
            cout << vm_commands[30] << endl;
            cout << command_pointer << endl;
            return(ERR_OF_UNKNOWN_OP);
        }

        if(stack_pointer+vm_vommands_stack_offsets[index_of_operation_now] < -1)
        {
            return(ERR_OF_SP_MINUS_ONE);
        }

        if(stack_pointer+vm_vommands_stack_offsets[index_of_operation_now] >= Q_ELEMS_IN_STACK)
        {
            return(ERR_OF_STACK_OVERFLOW);
        }

        if(flag_div_by_zero == 1)
        {
            return(ERR_OF_DIV_BY_ZERO);
        }

        switch(index_of_operation_now)
        {

// arifm operations ///////////////////////////////////////////////////////

            case OP_ADD:
            {
                _stack[stack_pointer-1] = MY_NUM_ADD(_stack[stack_pointer-1], _stack[stack_pointer]);
                stack_pointer-=1;
            } break;

            case OP_MIN:
            {
                _stack[stack_pointer-1] = MY_NUM_MIN(_stack[stack_pointer-1], _stack[stack_pointer]);
                stack_pointer-=1;
            } break;

            case OP_DIV:
            {
                _stack[stack_pointer-1] = MY_NUM_DIV(_stack[stack_pointer-1], _stack[stack_pointer]);
                stack_pointer-=1;
            } break;

            case OP_MULT:
            {
                _stack[stack_pointer-1] = MY_NUM_MULT(_stack[stack_pointer-1], _stack[stack_pointer]);
                stack_pointer-=1;
            } break;

            case OP_UNAR_MIN:
            {
                _stack[stack_pointer] = MY_NUM_UNAR_MIN(_stack[stack_pointer]);
            } break;

// comparison operations /////////////////////////////////////////////////////////

            case OP_BIGGER:
            {
                if(MY_NUM_BIGGER(_stack[stack_pointer-1], _stack[stack_pointer]))
                {
                    _stack[stack_pointer-1] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer-1] = "+0.0";
                }
                stack_pointer-=1;
            } break;

            case OP_BIGGER_OR_EQUAL:
            {
                if(MY_NUM_BIGGER_OR_EQUAL(_stack[stack_pointer-1], _stack[stack_pointer]))
                {
                    _stack[stack_pointer-1] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer-1] = "+0.0";
                }
                stack_pointer-=1;
            } break;

            case OP_LESS:
            {
                if(MY_NUM_LESS(_stack[stack_pointer-1], _stack[stack_pointer]))
                {
                    _stack[stack_pointer-1] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer-1] = "+0.0";
                }
                stack_pointer-=1;
            } break;

            case OP_LESS_OR_EQUAL:
            {
                if(MY_NUM_LESS_OR_EQUAL(_stack[stack_pointer-1], _stack[stack_pointer]))
                {
                    _stack[stack_pointer-1] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer-1] = "+0.0";
                }
                stack_pointer-=1;
            } break;

            case OP_EQUAL:
            {
                if(MY_NUM_EQUAL(_stack[stack_pointer-1], _stack[stack_pointer]))
                {
                    _stack[stack_pointer-1] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer-1] = "+0.0";
                }
                stack_pointer-=1;
            } break;

            case OP_NOT_EQUAL:
            {
                if(MY_NUM_NOT_EQUAL(_stack[stack_pointer-1], _stack[stack_pointer]))
                {
                    _stack[stack_pointer-1] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer-1] = "+0.0";
                }
                stack_pointer-=1;
            } break;

// logic operations //////////////////////////////////////////////////////////////

            case OP_LOGIC_TILDA:
            {
                if(_stack[stack_pointer] == "+0.0" || _stack[stack_pointer] == "-0.0")
                {
                    _stack[stack_pointer] = "+1.0";
                }
                else
                {
                    _stack[stack_pointer] = "+0.0";
                }
            } break;

// flow_control operations ///////////////////////////////////////////////////////

            case OP_JMP:
            {
                command_pointer += my_num_to_int(command_arr[command_pointer+1])-1;
            } break;

            case OP_JMP_IF_ZERO:
            {
                if(_stack[stack_pointer] == "+0.0" || _stack[stack_pointer] == "-0.0")
                {
                    command_pointer += my_num_to_int(command_arr[command_pointer+1])-1;
                }
                else
                {
                    command_pointer += 1;
                }
                stack_pointer-=1;
            } break;

// stack operations /////////////////////////////////////////////////////////////////

            case OP_POP:
            {
                stack_pointer-=1;
            } break;

            case OP_PUSH:
            {
                stack_pointer+=1;
                _stack[stack_pointer] = MY_NUM_NORMAL_MODE(command_arr[command_pointer+1]);
                command_pointer+=1;
            } break;

// vm operations /////////////////////////////////////////////////////////////////

            case OP_HALT:
            {
                return(ALL_OK);
            } break;

// functions ///////////////////////////////////////////////////////////////////////////////

            case OP_CALL:
            {
                if(stack_pointer+my_num_to_int(command_arr[command_pointer+2])+3 >= Q_ELEMS_IN_STACK)
                {
                    return(ERR_OF_STACK_OVERFLOW);
                }

                stack_pointer+=1;
                _stack[stack_pointer] = INT_TO_MY_NUM(frame_pointer);
                frame_pointer = stack_pointer;

                stack_pointer+=1;
                command_pointer+=1;
                _stack[stack_pointer] = INT_TO_MY_NUM(q_argvs);
                q_argvs = my_num_to_int(command_arr[command_pointer]);

                stack_pointer+=1;
                command_pointer+=1;
                _stack[stack_pointer] = INT_TO_MY_NUM(command_pointer);
                q_vars = my_num_to_int(command_arr[command_pointer]);

                for(index=0; index<q_vars; index++)
                {
                    _stack[stack_pointer+1+index] = "+0.0";
                }

                stack_pointer+=q_vars;

                // stack
                // |
                // V
                // [f_p    ]
                // [q_argvs]
                // [c_p ]

            } break;

            case OP_RET:
            {
                temp1 = _stack[stack_pointer];

                command_pointer = my_num_to_int(_stack[frame_pointer+2])+2;


                stack_pointer = frame_pointer-q_argvs-1;
                q_argvs = my_num_to_int(_stack[frame_pointer+1]);


                frame_pointer = my_num_to_int(_stack[frame_pointer]);

                stack_pointer+=1;
                _stack[stack_pointer] = temp1;
            } break;

            case OP_LOAD_VAR_BY_COMMAND:
            {
                stack_pointer   += 1;
                command_pointer += 1;
                _stack[stack_pointer] = _stack[frame_pointer+3+my_num_to_int(command_arr[command_pointer])];
            } break;

            case OP_WRITE_TO_VAR_BY_COMMAND:
            {
                command_pointer += 1;
                _stack[frame_pointer+3+my_num_to_int(command_arr[command_pointer])] = _stack[stack_pointer];
                stack_pointer   -= 1;
            } break;

            case OP_LOAD_VAR_BY_TOP_STACK:
            {
                _stack[stack_pointer] = _stack[frame_pointer + 3 + my_num_to_int(_stack[stack_pointer])];
            } break;

            case OP_WRITE_TO_VAR_BY_TOP_STACK:
            {
                _stack[frame_pointer+3+my_num_to_int(_stack[stack_pointer])] = _stack[stack_pointer-1];
                stack_pointer   -= 2;
            } break;

            case OP_LOAD_ARG_BY_COMMAND:
            {
                stack_pointer   += 1;
                command_pointer += 1;
                _stack[stack_pointer] = _stack[frame_pointer - q_argvs + my_num_to_int(command_arr[command_pointer])];
            } break;

            case OP_WRITE_TO_ARG_BY_COMMAND:
            {
                command_pointer += 1;
                _stack[frame_pointer + q_argvs - my_num_to_int(command_arr[command_pointer])] = _stack[stack_pointer];
                stack_pointer   -= 1;
            } break;

            case OP_LOAD_ARG_BY_TOP_STACK:
            {
                _stack[stack_pointer] = _stack[frame_pointer - q_argvs + my_num_to_int(_stack[stack_pointer])];
            } break;

            case OP_WRITE_TO_ARG_BY_TOP_STACK:
            {
                _stack[frame_pointer - q_argvs + my_num_to_int(_stack[stack_pointer])] = _stack[stack_pointer-1];
                stack_pointer   -= 2;
            } break;

            case OP_LOAD_POINTER_TO_VAR_BY_TOP_STACK:
            {
                _stack[stack_pointer] = INT_TO_MY_NUM(frame_pointer+3+my_num_to_int(_stack[stack_pointer]));
            } break;

            case OP_LOAD_POINTER_TO_ARG_BY_TOP_STACK:
            {
                _stack[stack_pointer] = INT_TO_MY_NUM(frame_pointer - q_argvs + my_num_to_int(_stack[stack_pointer]));
            } break;

            case OP_LOAD_POINTER_TO_VAR_BY_COMMAND:
            {
                command_pointer+=1;
                stack_pointer+=1;
                _stack[stack_pointer] = INT_TO_MY_NUM(frame_pointer+3+my_num_to_int(command_arr[command_pointer]));
            } break;

            case OP_LOAD_POINTER_TO_ARG_BY_COMMAND:
            {
                command_pointer+=1;
                stack_pointer+=1;
                _stack[stack_pointer] = INT_TO_MY_NUM(frame_pointer - q_argvs + my_num_to_int(command_arr[command_pointer]));
            } break;

            case OP_WRITE_BY_TOP_STACK:
            {
                /*

                stack |
                      V

                [ a  ]
                [ b  ]

                stack[a] = stack[b]

                */

                _stack[my_num_to_int(_stack[stack_pointer-1])] = _stack[stack_pointer];
                stack_pointer-=2;
            } break;


            case OP_LOAD_BY_TOP_STACK:
            {
                _stack[stack_pointer] = _stack[my_num_to_int(_stack[stack_pointer])];
            } break;

// other

            case OP_WRITELN_TOP_STACK:
            {
                cout << _stack[stack_pointer]  << endl;
                stack_pointer-=1;
            } break;

            case OP_WRITE_CHAR_TOP_STACK:
            {
                cout << (char)my_num_to_int(_stack[stack_pointer]);
                stack_pointer-=1;
            } break;

            case INT_16:
			{
				switch(my_num_to_int(_stack[stack_pointer]))
				{
					case 0:
					{
						system("cls");
						stack_pointer-=1;
					}  break;
					case 1:
					{
						goto_for_cursor(my_num_to_int(_stack[stack_pointer-2]), my_num_to_int(_stack[stack_pointer-1]));
						stack_pointer-=3;
					}  break;
					case 2:
					{
						::Beep(my_num_to_int(_stack[stack_pointer-2]), my_num_to_int(_stack[stack_pointer-1]));
						stack_pointer-=3;
					}  break;
					case 3:
					{
						::Sleep(my_num_to_int(_stack[stack_pointer-1]));
						stack_pointer-=2;
					}  break;
					default :
					{
						return(ERR_UNKNOWN_INT);
					} break;
				}

			} break;
        }
    }
}

void show_vm_state(int sp, int cp)
{
    vector <string> stack_string, command_string;
    int i;
    system("cls");
    for(i=0; i<=sp; i++)
    {
        stack_string.push_back(_stack[i]);
    }
    for(i=0; i<=cp; i++)
    {
        command_string.push_back(command_arr[i]);
    }
    for(i=0; i<=max(cp, sp); i++)
    {
        if(i<=sp)
        {
            cout << setw(30) << stack_string[i];
        }
        else
        {
            cout << setw(30) << "";
        }

        if(i == cp)
        {
            cout << setw(5) << "->";
        }
        else
        {
            cout << setw(5) << "";
        }

        if(i<=cp)
        {
            cout << setw(30) << command_string[i];
        }
        else
        {
            cout << setw(30) << "";
        }
        cout << endl;
    }
}

int main()
{
    //cout << MY_NUM_ADD("-019996.0", "+12000.0") << endl;
    //cout << MY_NUM_ADD("+12000.0", "-019996.0") << endl;
    //cout << MY_NUM_NORMAL_MODE("+1000000000.00000") << endl;
    //cout << div_ten("+15.1") << endl;
    //cout << MY_NUM_NORMAL_MODE("+0.0") << endl;
    //cout << MY_NUM_DIV("-0.1", "-0.0") << endl;
    //cout << MY_NUM_MULT("+0.2", "+0.03") << endl;

    /*command_arr[0]   = "push";
    command_arr[1]   = "+0.200";
    command_arr[2]   = "call";
    command_arr[3]   = "1";
    command_arr[4]   = "3";
    command_arr[5]   = "jmp";
    command_arr[6]   = "4";
    command_arr[7]   = "jmp";
    command_arr[8]   = "6";
    command_arr[9]   = "push";
    command_arr[10]  = "+0.0";
    command_arr[11]  = "load_arg_by_top_stack";
    command_arr[12]  = "return";
    command_arr[13]  = "halt";*/


    /*command_arr[0]    = "push";
    command_arr[1]    = "+100.0";
    command_arr[2]    = "push";
    command_arr[3]    = "+200.0";
    command_arr[4]    = "call";
    command_arr[5]    = "+2.0";
    command_arr[6]    = "+3.0";
    command_arr[7]    = "load_arg_by_command";
    command_arr[8]    = "+1.0";
    command_arr[9]    = "push";
    command_arr[10]   = "+1.0";
    command_arr[11]   = "load_pointer_to_arg_by_top_stack";
    command_arr[12]    = "push";
    command_arr[13]   = "+122.0";
    command_arr[14]   = "write_by_top_stack";
    command_arr[15]   = "return";
    command_arr[16]   = "halt";*/



    /*command_arr[0]    = "call";
    command_arr[1]    = "+0.0";
    command_arr[2]    = "+3.0";
    command_arr[3]    = "push";
    command_arr[4]    = "+2.0";
    command_arr[5]    = "load_pointer_to_var_by_command";
    command_arr[6]    = "+0.0";
    command_arr[7]    = "halt";*/

    int index, index1;

    tokens = lexer();
    cout << "==================" << endl;
    parse_module();

    //show_ast(0, 0);
    //cout << "==================" << endl;

    test_inline_functions_q_argvs();

    //cout << "==================" << endl;

    //show_ast(0, 0);

    //cout << "==================" << endl;

    delete_fors_from_ast();

    //show_ast(0, 0);

    //cout << "==================" << endl;

    delete_whiles_from_ast();

    //show_ast(0, 0);

    //cout << "==================" << endl;

    make_ST();

    show_ST();

    show_ast(0, 0);

    test_ast_with_st(0);

    test_function_main();

    cout << "@@@@@@@@@@@@@@@@@@@@@" << endl;


    generate_code();
    show_commands();

    cout << "@@@@@@@@@@@@@@@@@@@@@" << endl;

    delete_labels_from_code();
    show_commands();


    for(index=0; index<commands_for_vm.size(); index++)
    {
        command_arr[index] = commands_for_vm[index];
    }

    getch();

    cout << run_vm();

    getch();
    return 0;
}
