#include <iostream>
#include <conio.h>
#include <fstream>
#include <vector>
#include <string.h>
#include <string>
#include <iomanip>


using namespace std;


/*
<module>         ::= <function>{<function>} ;

<function>       ::= '#function' <identifer> '('
                     [<1_var_decl> { ',' <1_var_decl>}] ')' '{' {<many_var_decl> ';'}
                     {<statement> | <if_else> | <while> | <for> | <goto_statement>} '}';

<1_var_decl>     ::= ('#var' <identifer>) | ('#var' <identifer> '[' <constant> ']') ;

<many_var_decl>  ::= '#var' [(<identifer> ) | ( <identifer> '[' <constant> ']') {',' ( <identifer> ) | ( <identifer> '[' <constant> ']')}] ;

<if_else>        ::= '#if' '(' <expression> ')' '{'
                      {<statement> | <if_else> | <while> | <for> | <goto_statement>} '}'
                      ['#else' '{'
                      {<statement> | <if_else> | <while> | <for> | <goto_statement>} '}'] ;

<while>          ::= '#while' '(' <expression> ')' '{'
                      {<statement> | <if_else> | <while> | <for> | <goto_statement>} '}' ;

<for>            ::= '#for' '(' <statement> <statement> <expression> ')' '{'
                      {<statement> | <if_else> | <while> | <for> | <goto_statement>} '}' ;

<statement>      ::= {<expression> | <assigment>} ';' ;

<goto_statement> ::= (('@goto' <identifer>) | ('@label' <identifer>) | '@break' | '@continue') ';' ;

<assigment>      ::= '=' '(' <l_val> ',' <expression> ')' ';' ;

<l_val>          ::= <identifer> | (<identifer> '[' <expression> ']') | ('@link' '(' <identifer> ')' ) | ('@link' '(' <identifer> '[' <expression> ']' ')');

<expression>     ::= <const> | ( <identifer> ( <expression>  {',' <expression> })) | <identifer> '[' <expression> ']' | <identifer> ;

<identifer>      ::= '_' | 'a' | 'b' | 'c' | ... | 'z' | 'A' | 'B' | 'C' | ... | 'Z'
                     { | '_' | '9' | ... | '3' | '2' | '1' | '0' | 'a' | 'b' | 'c' | ... | 'z' | 'A' | 'B' | 'C' | ... | 'Z'}
<const>          ::= ('+' | '-') '9' | ... | '3' | '2' | '1' | '0' {'9' | ... | '3' | '2' | '1' | '0'} '.'
                     '9' | ... | '3' | '2' | '1' | '0' {'9' | ... | '3' | '2' | '1' | '0'} ;

*/

enum token_names {OPEN_BRACKET = 0, CLOSE_BRACKET, OPEN_SQUAR_BRACKET, CLOSE_SQUAR_BRACKET,
                  OPEN_BRACE, CLOSE_BRACE, COMMA, SEMICOLON, INDENTIF, TT_CONST, NO_TYPE};

enum AST_types_of_edges {ARG_OF_FUNCTION=0, IN_FUNCTION, OTHER_EDGE_TYPE, IN_IF, IN_ELSE, IN_WHILE, IN_FOR};
enum types_of_identifers_for_symbol_table {ST_VARIABLE_NAME=0, ST_FUNCTION_NAME, ST_LABEL_NAME}; // ST - symbol type

vector <string> types_of_identifers_for_symbol_table_comparison = {"ST_VARIABLE_NAME", "ST_FUNCTION_NAME", "ST_LABEL_NAME"};

vector <string> eges_types_string_comparison = { "ARG_OF_FUNCTION", "IN_FUNCTION", "OTHER_EDGE_TYPE",
                                                 "IN_IF", "IN_ELSE", "IN_WHILE", "IN_FOR"};

enum AST_node_types     {VARIABLE=0, FUNCTION, LABEL_NAME, OTHER_NODE_TYPE, CONSTANT};

vector <string> node_types_comparison = {"VARIABLE", "FUNCTION", "LABEL_NAME", "OTHER_NODE_TYPE", "CONSTANT"};

vector <string> inline_function_names = {"+", "-", "*", "/", "=", "||", "&&", ">", "<", ">=", "<=", "==", "!=", "!",
                                         "@link", "@pointer", "@UNAR_MINUS", "#return", "#writeln", "#print", "@load", "#int_16", "#push"};

struct token
{
    int line_num, colomn_num;
    string content;
    int token_type;
};

struct AST_node
{
    string content;
    int node_type;

    int parent;
    int type_of_edge_parent;

    vector <int> child;
    vector <int> types_of_edges_childs;

    int index_of_node_of_symbol_table;
};

struct ST_node
{
    vector <string> simbol_names;
    vector <int>    simbol_types;
    vector <int>    q_variables; // for arrays
    vector <int>    index_of_variable; // for variables
    vector <int>    index_of_label; // for labels
    vector <int>    index_of_arg; // for variables

    int parent;
    vector <int> child;
};

void parse_identifer(int index_of_parent, int parrent_type_connection, int node_type = OTHER_NODE_TYPE);
void parse_const(int index_of_parent, int parrent_type_connection);
void parse_1_var_decl(int index_of_parent, int parrent_type_connection);
void parse_many_var_decl(int index_of_parent, int parrent_type_connection);
void parse_statement(int index_of_parent, int parrent_type_connection);
void parse_if_else(int index_of_parent, int parrent_type_connection);
void parse_l_val(int index_of_parent, int parrent_type_connection);
void parse_assigment(int index_of_parent, int parrent_type_connection);
void parse_goto_statement(int index_of_parent, int parrent_type_connection);
void parse_while(int index_of_parent, int parrent_type_connection);
void parse_for(int index_of_parent, int parrent_type_connection);
void parse_module();

void show_ast(int depth, int index_of_node);


bool is_this_my_num(string n);


int index_of_token_now=0;

vector <token> tokens;
vector <AST_node> ast_nodes;
vector <ST_node> st_nodes;

int index_of_arg;

bool _is_digit(char ch)
{
    string s = "0123456789";
    int index;
    for(index=0; index<10; index++)
    {
        if(ch == s[index])
        {
            return (true);
        }
    }
    return (false);
}

token get_token_by_index(int index)
{
    token token_return;
    token_return.colomn_num =tokens.back().colomn_num+1;
    token_return.line_num   =tokens.back().line_num;
    token_return.content    ="";
    token_return.token_type =NO_TYPE;

    if(index<0 || index>=tokens.size())
    {
        return token_return;
    }
    else
    {
        return tokens[index];
    }
}

bool is_identifer(string s)
{
    if(s.length()<4)
    {
        return 1;
    }
    else
    {
        if(s[0] == '+' || s[0] == '-')
        {
            return 0;
        }
        return 1;
    }

}

vector <token> lexer()
{
    ifstream input_file;
    vector <token> tokens;
    token token_now;
    string input, line;
    int index, index1, line_num_now = 0;

    vector <string> delimeters_to_delete = {" ", "\n", "\t"};
    vector <string> other_delimeters = {",", "[", "]", "(", ")", ";"};

    vector <int> tokens_types = {OPEN_BRACKET, CLOSE_BRACKET, OPEN_SQUAR_BRACKET, CLOSE_SQUAR_BRACKET,
                                 OPEN_BRACE, CLOSE_BRACE, COMMA, SEMICOLON};

    vector <string> tokens_comparison_types = {"(" , ")", "[", "]", "{", "}", ",", ";",
                                               "identif", "const"};

    input_file.open("input.txt");

    while(!input_file.eof())
    {
        getline(input_file, line);
        input = "";
        line  += '\n';

        for(index=0; index<line.size(); index++)
        {
            input += line[index];

            for(index1=0; index1<delimeters_to_delete.size(); index1++)
            {
                if(input.find(delimeters_to_delete[index1]) != string::npos)
                {
                    input.erase(input.find(delimeters_to_delete[index1]),
                                delimeters_to_delete[index1].length());

                    if(input!= "")
                    {
                        token_now.content = input;
                        token_now.line_num = line_num_now;
                        token_now.colomn_num = index;

                        tokens.push_back(token_now);
                    }

                    input = "";
                }
            }

            for(index1=0; index1<other_delimeters.size(); index1++)
            {
                if(input.find(other_delimeters[index1]) != string::npos)
                {

                    token_now.content = input;
                    token_now.content.erase(token_now.content.size()-other_delimeters[index1].length());
                    token_now.line_num = line_num_now;
                    token_now.colomn_num = index;

                    if(token_now.content != "")
                    {
                        tokens.push_back(token_now);
                    }


                    token_now.content = other_delimeters[index1];
                    token_now.line_num = line_num_now;
                    token_now.colomn_num = index;

                    tokens.push_back(token_now);


                    input = "";
                    break;
                }
            }
        }

        line_num_now+=1;
    }

    input_file.close();

    for(index=0; index<tokens.size(); index++)
    {
        for(index1=0; index1<tokens_types.size(); index1++)
        {
            if(tokens[index].content == tokens_comparison_types[index1])
            {
                tokens[index].token_type = index1;
                break;
            }
        }

        if(index1 == tokens_types.size())
        {
            if(is_identifer(tokens[index].content) == 1)
            {
                tokens[index].token_type = INDENTIF;
            }
            else
            {
                tokens[index].token_type = TT_CONST;
            }
        }
    }

    for(index=0; index<tokens.size(); index++)
    {
        cout << setw(10) << tokens[index].content  << " " << setw(10)
             << setw(10) << tokens[index].line_num << " " << setw(10)
             << tokens[index].colomn_num << " " << tokens_comparison_types[tokens[index].token_type]
             << endl;
    }

    return tokens;
}


// build AST

void raise_error(string err_message, int line_n, int column_n)
{
    cout << err_message << " " << "line: " << line_n << " column: "  << column_n << endl;
    getch();
    exit(0);
}

void parse_function(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    if (token_now.content != "#function")
    {
        raise_error("word <#function> expected", token_now.line_num, token_now.colomn_num);
    }

    ast_node_now.content = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    index_of_token_now+=1;

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

    parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "(")
    {
        raise_error("( expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ")")
    {
        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(ARG_OF_FUNCTION);

        parse_1_var_decl(AST_node_now_index, ARG_OF_FUNCTION);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);
    }

    while(token_now.content != ")")
    {

        if(token_now.content != ",")
        {
            raise_error(", expected", token_now.line_num, token_now.colomn_num);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(ARG_OF_FUNCTION);

        parse_1_var_decl(AST_node_now_index, ARG_OF_FUNCTION);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(index_of_token_now >= tokens.size())
        {
            raise_error(") expected", token_now.line_num, token_now.colomn_num);
        }
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "{")
    {
        raise_error("{ expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content == "#var")
    {
        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);

        parse_many_var_decl(AST_node_now_index, IN_FUNCTION);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(token_now.content != ";")
        {
            raise_error("; expected", token_now.line_num, token_now.colomn_num);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);
    }

    while(token_now.content != "}")
    {
        if(token_now.content == "#if")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_if_else(AST_node_now_index, IN_FUNCTION);
        }
        else if(token_now.content == "#while")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_while(AST_node_now_index, IN_FUNCTION);
        }
        else if(token_now.content == "#for")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_for(AST_node_now_index, IN_FUNCTION);
        }
        else if(token_now.content == "@break"
                || token_now.content == "@goto"
                || token_now.content == "@continue"
                || token_now.content == "@label")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_goto_statement(AST_node_now_index, IN_FUNCTION);
        }
        else if(token_now.content == "=")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_assigment(AST_node_now_index, IN_FUNCTION);
        }
        else
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_statement(AST_node_now_index, IN_FUNCTION);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(index_of_token_now >= tokens.size())
        {
            raise_error("} expected", token_now.line_num, token_now.colomn_num);
        }
    }
}

void parse_1_var_decl(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    AST_node_now_index = ast_nodes.size();

    token_now = get_token_by_index(index_of_token_now);

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

    if(token_now.content != "#var")
    {
        raise_error("#var expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content == "[")
    {
        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        ast_nodes[AST_node_now_index+1].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index+1].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

        parse_const(AST_node_now_index+1, OTHER_EDGE_TYPE);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(token_now.content != "]")
        {
            raise_error("it must be ]", token_now.line_num, token_now.colomn_num);
        }
    }
    else
    {
        index_of_token_now-=1;
    }
}

void parse_many_var_decl(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    AST_node_now_index = ast_nodes.size();

    token_now = get_token_by_index(index_of_token_now);

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    if(token_now.content != "#var")
    {
        raise_error("#var expected", token_now.line_num, token_now.colomn_num);
    }

    do
    {
        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);


        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);
        parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(token_now.content == "[")
        {
            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);

            ast_nodes[ast_nodes.size()-1].child.push_back(ast_nodes.size());
            ast_nodes[ast_nodes.size()-1].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

            parse_const(AST_node_now_index+1, OTHER_EDGE_TYPE);

            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);

            if(token_now.content != "]")
            {
                raise_error("it must be ]", token_now.line_num, token_now.colomn_num);
            }

            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);
        }

    } while(token_now.content == ",");

    index_of_token_now-=1;
}

void parse_identifer(int index_of_parent, int parrent_type_connection, int node_type)
{
    token token_now;
    AST_node ast_node_now;

    int index, index1;

    string letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
    string letters_and_nums = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789";
    string temp;

    token_now = get_token_by_index(index_of_token_now);

    for(index=0; index<token_now.content.length(); index++)
    {
        temp = "";
        temp+=token_now.content[index];

        if(index == 0)
        {
            if(letters.find(temp) == string::npos)
            {
                temp += ": unexpected in identif";
                raise_error(temp, token_now.line_num, token_now.colomn_num);
            }
        }
        else
        {
            if(letters_and_nums.find(temp) == string::npos)
            {
                temp += ": unexpected in identif";
                raise_error(temp, token_now.line_num, token_now.colomn_num);
            }
        }
    }

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = node_type;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);
}

void parse_const(int index_of_parent, int parrent_type_connection)
{
    token token_now;
    AST_node ast_node_now;

    token_now = get_token_by_index(index_of_token_now);

    if(is_this_my_num(token_now.content) == false)
    {
        raise_error("it must be a constant", token_now.line_num, token_now.colomn_num);
    }

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = CONSTANT;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);
}

void parse_expression(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now, token_after_token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);
    token_after_token_now = get_token_by_index(index_of_token_now+1);

    if(is_this_my_num(token_now.content) == 1)
    {
        parse_const(index_of_parent, parrent_type_connection);
    }
    else if(token_after_token_now.content == "(")
    {
        ast_node_now.content   = token_now.content;
        ast_node_now.node_type = FUNCTION;
        ast_node_now.parent    = index_of_parent;
        ast_node_now.type_of_edge_parent = parrent_type_connection;

        ast_nodes.push_back(ast_node_now);

        index_of_token_now+=2;
        token_now = get_token_by_index(index_of_token_now);

        AST_node_now_index = ast_nodes.size()-1;

        while(token_now.content != ")")
        {
            cout << token_now.content << endl;
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);

            parse_expression(AST_node_now_index, IN_FUNCTION);

            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);

            if(token_now.content != "," && token_now.content != ")")
            {
                cout << token_now.content << endl;
                raise_error(") or , expected", token_now.line_num, token_now.colomn_num);
            }

            if(token_now.content == ",")
            {
                index_of_token_now+=1;
                token_now = get_token_by_index(index_of_token_now);
            }

            if(index_of_token_now >= tokens.size())
            {
                raise_error(") expected", token_now.line_num, token_now.colomn_num);
            }
        }
    }
    else if(token_after_token_now.content == "[")
    {
        parse_identifer(index_of_parent, parrent_type_connection, VARIABLE);
        AST_node_now_index = ast_nodes.size()-1;
        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());

        index_of_token_now+=2;

        parse_expression(AST_node_now_index, OTHER_EDGE_TYPE);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(token_now.content != "]")
        {
            raise_error("] or , expected", token_now.line_num, token_now.colomn_num);
        }
    }
    else
    {
        parse_identifer(index_of_parent, parrent_type_connection, VARIABLE);
    }
}

void parse_statement(int index_of_parent, int parrent_type_connection)
{
    token token_now;
    AST_node ast_node_now;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ";")
    {
        parse_expression(index_of_parent, parrent_type_connection);
    }
    else
    {
        return;
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ";")
    {
        raise_error("; or , expected", token_now.line_num, token_now.colomn_num);
    }
}

void parse_if_else(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    if(token_now.content != "#if")
    {
        raise_error("#if expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "(")
    {
        raise_error("( expected", token_now.line_num, token_now.colomn_num);
    }

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

    index_of_token_now+=1;

    parse_expression(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ")")
    {
        raise_error(") expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "{")
    {
        raise_error("{ expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    while(token_now.content != "}")
    {
        if(token_now.content == "#if")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_IF);
            parse_if_else(AST_node_now_index, IN_IF);
        }
        else if(token_now.content == "#while")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_IF);
            parse_while(AST_node_now_index, IN_IF);
        }
        else if(token_now.content == "#for")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_IF);
            parse_for(AST_node_now_index, IN_IF);
        }
        else if(token_now.content == "@break"
                || token_now.content == "@goto"
                || token_now.content == "@continue"
                || token_now.content == "@label")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_IF);
            parse_goto_statement(AST_node_now_index, IN_IF);
        }
        else if(token_now.content == "=")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_IF);
            parse_assigment(AST_node_now_index, IN_IF);
        }
        else
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_IF);
            parse_statement(AST_node_now_index, IN_IF);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(index_of_token_now >= tokens.size())
        {
            raise_error("} expected", token_now.line_num, token_now.colomn_num);
        }
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content == "#else")
    {
        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(token_now.content != "{")
        {
            raise_error("{ expected", token_now.line_num, token_now.colomn_num);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        while(token_now.content != "}")
        {
            if(token_now.content == "#if")
            {
                ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
                ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_ELSE);
                parse_if_else(AST_node_now_index, IN_ELSE);
            }
            else if(token_now.content == "#while")
            {
                ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
                ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_ELSE);
                parse_while(AST_node_now_index, IN_ELSE);
            }
            else if(token_now.content == "#for")
            {
                ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
                ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_ELSE);
                parse_for(AST_node_now_index, IN_ELSE);
            }
            else if(token_now.content == "@break"
                    || token_now.content == "@goto"
                    || token_now.content == "@continue"
                    || token_now.content == "@label")
            {
                ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
                ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_ELSE);
                parse_goto_statement(AST_node_now_index, IN_ELSE);
            }
            else if(token_now.content == "=")
            {
                ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
                ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_ELSE);
                parse_assigment(AST_node_now_index, IN_ELSE);
            }
            else
            {
                ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
                ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_ELSE);
                parse_statement(AST_node_now_index, IN_ELSE);
            }

            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);

            if(index_of_token_now >= tokens.size())
            {
                raise_error("} expected", token_now.line_num, token_now.colomn_num);
            }
        }
    }
    else
    {
        index_of_token_now-=1;
    }
}

void parse_while(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    if(token_now.content != "#while")
    {
        raise_error("#while expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "(")
    {
        raise_error("( expected", token_now.line_num, token_now.colomn_num);
    }

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

    index_of_token_now+=1;

    parse_expression(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ")")
    {
        raise_error(") expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "{")
    {
        raise_error("{ expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    while(token_now.content != "}")
    {
        if(token_now.content == "#if")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_WHILE);
            parse_if_else(AST_node_now_index, IN_WHILE);
        }
        else if(token_now.content == "#while")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_WHILE);
            parse_while(AST_node_now_index, IN_WHILE);
        }
        else if(token_now.content == "#for")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_WHILE);
            parse_for(AST_node_now_index, IN_WHILE);
        }
        else if(token_now.content == "@break"
                || token_now.content == "@goto"
                || token_now.content == "@continue"
                || token_now.content == "@label")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_WHILE);
            parse_goto_statement(AST_node_now_index, IN_WHILE);
        }
        else if(token_now.content == "=")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_WHILE);
            parse_assigment(AST_node_now_index, IN_WHILE);
        }
        else
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_WHILE);
            parse_statement(AST_node_now_index, IN_WHILE);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(index_of_token_now >= tokens.size())
        {
            raise_error("} expected", token_now.line_num, token_now.colomn_num);
        }
    }
}

void parse_for(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    if(token_now.content != "#for")
    {
        raise_error("#for expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "(")
    {
        raise_error("( expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
    parse_assigment(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
    parse_statement(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
    parse_expression(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ")")
    {
        raise_error(") expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "{")
    {
        raise_error("{ expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    while(token_now.content != "}")
    {
        if(token_now.content == "#if")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
            parse_if_else(AST_node_now_index, IN_FOR);
        }
        else if(token_now.content == "#while")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
            parse_while(AST_node_now_index, IN_FOR);
        }
        else if(token_now.content == "#for")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
            parse_for(AST_node_now_index, IN_FOR);
        }
        else if(token_now.content == "@break"
                || token_now.content == "@goto"
                || token_now.content == "@continue"
                || token_now.content == "@label")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
            parse_goto_statement(AST_node_now_index, IN_FOR);
        }
        else if(token_now.content == "=")
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
            parse_assigment(AST_node_now_index, IN_FOR);
        }
        else
        {
            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FOR);
            parse_statement(AST_node_now_index, IN_FOR);
        }

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(index_of_token_now >= tokens.size())
        {
            raise_error("} expected", token_now.line_num, token_now.colomn_num);
        }
    }
}

void parse_assigment(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now, token_after_token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "=")
    {
        raise_error("= expected", token_now.line_num, token_now.colomn_num);
    }

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = FUNCTION;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != "(")
    {
        raise_error("( expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
    parse_l_val(AST_node_now_index, IN_FUNCTION);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ",")
    {
        raise_error(", expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
    parse_expression(AST_node_now_index, IN_FUNCTION);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ")")
    {
        raise_error(") expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ";")
    {
        raise_error("; expected", token_now.line_num, token_now.colomn_num);
    }
}

void parse_l_val(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now, token_after_token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);
    token_after_token_now = get_token_by_index(index_of_token_now+1);


    if(token_after_token_now.content == "[")
    {

        ast_node_now.content   = token_now.content;
        ast_node_now.node_type = VARIABLE;
        ast_node_now.parent    = index_of_parent;
        ast_node_now.type_of_edge_parent = parrent_type_connection;

        ast_nodes.push_back(ast_node_now);

        AST_node_now_index = ast_nodes.size()-1;

        parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE, VARIABLE);

        index_of_token_now+=2;

        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);
        parse_expression(AST_node_now_index, OTHER_EDGE_TYPE);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);

        if(token_now.content != "]")
        {
            raise_error("] expected", token_now.line_num, token_now.colomn_num);
        }
    }
    else if(token_now.content == "@link")
    {

        ast_node_now.content   = token_now.content;
        ast_node_now.node_type = FUNCTION;
        ast_node_now.parent    = index_of_parent;
        ast_node_now.type_of_edge_parent = parrent_type_connection;

        ast_nodes.push_back(ast_node_now);

        AST_node_now_index = ast_nodes.size()-1;

        token_after_token_now = get_token_by_index(index_of_token_now+3);

        if(token_after_token_now.content == "[")
        {
            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);

            if(token_now.content != "(")
            {
                raise_error("( expected", token_now.line_num, token_now.colomn_num);
            }

            index_of_token_now+=1;

            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_identifer(AST_node_now_index, IN_FUNCTION, VARIABLE);

            index_of_token_now+=2;

            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_expression(AST_node_now_index, IN_FUNCTION);

            index_of_token_now+=1;
            token_now = get_token_by_index(index_of_token_now);

            if(token_now.content != "]")
            {
                raise_error("] expected", token_now.line_num, token_now.colomn_num);
            }
        }
        else if (token_after_token_now.content == ")")
        {
            index_of_token_now+=1;

            token_now = get_token_by_index(index_of_token_now);

            if(token_now.content != "(")
            {
                raise_error("( expected", token_now.line_num, token_now.colomn_num);
            }

            index_of_token_now+=1;

            ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
            ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(IN_FUNCTION);
            parse_identifer(AST_node_now_index, IN_FUNCTION, VARIABLE);

            index_of_token_now+=1;

            token_now = get_token_by_index(index_of_token_now);

            if(token_now.content != ")")
            {
                raise_error(") expected", token_now.line_num, token_now.colomn_num);
            }
        }
        else
        {
            raise_error(") expected", token_after_token_now.line_num, token_after_token_now.colomn_num);
        }
    }
    else
    {
        ast_node_now.content   = token_now.content;
        ast_node_now.node_type = VARIABLE;
        ast_node_now.parent    = index_of_parent;
        ast_node_now.type_of_edge_parent = parrent_type_connection;

        ast_nodes.push_back(ast_node_now);

        AST_node_now_index = ast_nodes.size()-1;

        parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE, VARIABLE);
    }
}

void parse_goto_statement(int index_of_parent, int parrent_type_connection)
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    ast_node_now.content   = token_now.content;
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = index_of_parent;
    ast_node_now.type_of_edge_parent = parrent_type_connection;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    if(token_now.content == "@break" || token_now.content == "@continue")
    {

    }
    else if (token_now.content == "@goto")
    {
        index_of_token_now+=1;

        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);
        parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE, LABEL_NAME);
    }
    else if(token_now.content == "@label")
    {
        index_of_token_now+=1;

        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);
        parse_identifer(AST_node_now_index, OTHER_EDGE_TYPE, LABEL_NAME);
    }
    else
    {
        raise_error("key word expected", token_now.line_num, token_now.colomn_num);
    }

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    if(token_now.content != ";")
    {
        raise_error("; expected", token_now.line_num, token_now.colomn_num);
    }
}

void parse_module()
{
    int index;
    token token_now;
    AST_node ast_node_now;
    int AST_node_now_index;

    token_now = get_token_by_index(index_of_token_now);

    if (token_now.content != "#function")
    {
        raise_error("word <#function> expected", token_now.line_num, token_now.colomn_num);
    }

    ast_node_now.content = "@root";
    ast_node_now.node_type = OTHER_NODE_TYPE;
    ast_node_now.parent    = -1;
    ast_node_now.type_of_edge_parent = 0;

    ast_nodes.push_back(ast_node_now);

    AST_node_now_index = ast_nodes.size()-1;

    ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
    ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);
    parse_function(AST_node_now_index, OTHER_EDGE_TYPE);

    index_of_token_now+=1;
    token_now = get_token_by_index(index_of_token_now);

    while(index_of_token_now<tokens.size())
    {
        ast_nodes[AST_node_now_index].child.push_back(ast_nodes.size());
        ast_nodes[AST_node_now_index].types_of_edges_childs.push_back(OTHER_EDGE_TYPE);
        parse_function(AST_node_now_index, OTHER_EDGE_TYPE);

        index_of_token_now+=1;
        token_now = get_token_by_index(index_of_token_now);
    }
}

void delete_fors_from_ast()
{
    int index, index1;
    AST_node ast_node_now;
    int index_of_parent, parent_age_type, index_of_child, child_age_type;

    for(index=0; index<ast_nodes.size(); index++)
    {
        if(ast_nodes[index].content == "#for")
        {
            index_of_parent = ast_nodes[index].parent;
            parent_age_type = ast_nodes[index].type_of_edge_parent;

            for(index1=0; index1<ast_nodes[index_of_parent].child.size(); index1++)
            {
                if(ast_nodes[index_of_parent].child[index1] == index)
                {
                    break;
                }
            }

            ast_nodes[index_of_parent].child.insert(ast_nodes[index_of_parent].child.begin()+index1,
                                                    ast_nodes[index].child[0]);
            ast_nodes[index_of_parent].types_of_edges_childs.insert(ast_nodes[index_of_parent].types_of_edges_childs.begin()+index1,
                                                                    ast_nodes[index].type_of_edge_parent);

            ast_nodes[ast_nodes[index].child[0]].type_of_edge_parent = parent_age_type;

            ast_nodes[index].child.erase(ast_nodes[index].child.begin()+0);
            ast_nodes[index].types_of_edges_childs.erase(ast_nodes[index].types_of_edges_childs.begin()+0);

            index_of_child = ast_nodes[index].child[1];
            child_age_type = ast_nodes[index].types_of_edges_childs[1];

            ast_nodes[index].child.erase(ast_nodes[index].child.begin()+1);
            ast_nodes[index].types_of_edges_childs.erase(ast_nodes[index].types_of_edges_childs.begin()+1);

            ast_nodes[index].child.push_back(index_of_child);
            ast_nodes[index].types_of_edges_childs.push_back(child_age_type);

            ast_nodes[index].content = "#while";

            for(index1=0; index1<ast_nodes[index].child.size(); index1++)
            {
                ast_nodes[ast_nodes[index].child[index1]].type_of_edge_parent = IN_WHILE;
            }

            index=-1;
        }
    }
}

void delete_whiles_from_ast()
{
    int index, index1;
    AST_node ast_node_now;
    int index_of_parent, parent_age_type, index_of_child, child_age_type;
    string temp;
    int index_of_while = 0;

    for(index=0; index<ast_nodes.size(); index++)
    {
        if(ast_nodes[index].content == "#while")
        {
            index_of_parent = ast_nodes[index].parent;
            parent_age_type = ast_nodes[index].type_of_edge_parent;

            for(index1=0; index1<ast_nodes[index_of_parent].child.size(); index1++)
            {
                if(ast_nodes[index_of_parent].child[index1] == index)
                {
                    break;
                }
            }

        ast_node_now.content   = "@label";
        ast_node_now.node_type = OTHER_NODE_TYPE;
        ast_node_now.parent    = index_of_parent;
        ast_node_now.type_of_edge_parent = parent_age_type;
        ast_node_now.child.push_back(ast_nodes.size()+1);
        ast_node_now.types_of_edges_childs.push_back(OTHER_EDGE_TYPE);


        ast_nodes[index_of_parent].child.insert(ast_nodes[index_of_parent].child.begin()+index1,
                                                ast_nodes.size());
        ast_nodes[index_of_parent].types_of_edges_childs.insert(ast_nodes[index_of_parent].types_of_edges_childs.begin()+index1,
                                                                ast_nodes[index].type_of_edge_parent);
        ast_nodes.push_back(ast_node_now);

        temp = "@" + to_string(index_of_while);

        ast_node_now.content   = temp;
        ast_node_now.node_type = OTHER_NODE_TYPE;
        ast_node_now.parent    = ast_nodes.size()-1;
        ast_node_now.type_of_edge_parent = OTHER_EDGE_TYPE;
        ast_node_now.child.resize(0);
        ast_node_now.types_of_edges_childs.resize(0);

        ast_nodes.push_back(ast_node_now);

        ast_node_now.content   = "@goto";
        ast_node_now.node_type = OTHER_NODE_TYPE;
        ast_node_now.parent    = index;
        ast_node_now.type_of_edge_parent = IN_IF;
        ast_node_now.child.push_back(ast_nodes.size()+1);
        ast_node_now.types_of_edges_childs.push_back(OTHER_EDGE_TYPE);

        ast_nodes.push_back(ast_node_now);

        ast_nodes[index].child.push_back(ast_nodes.size()-1);
        ast_nodes[index].types_of_edges_childs.push_back(IN_IF);


        ast_node_now.content   = temp;
        ast_node_now.node_type = OTHER_NODE_TYPE;
        ast_node_now.parent    = ast_nodes.size()-1;
        ast_node_now.type_of_edge_parent = OTHER_EDGE_TYPE;
        ast_node_now.child.resize(0);
        ast_node_now.types_of_edges_childs.resize(0);

        ast_nodes.push_back(ast_node_now);

        ast_nodes[index].content = "#if";

        for(index1=1; index1<ast_nodes[index].child.size(); index1++)
        {
            ast_nodes[ast_nodes[index].child[index1]].type_of_edge_parent = IN_IF;
        }

        ast_nodes[ast_nodes[index].child[0]].type_of_edge_parent = OTHER_EDGE_TYPE;

        index_of_while+=1;
        index=-1;
        }
    }
}

void test_inline_functions_q_argvs()
{
    vector <int> q_argvs = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1};

    int index, index1;
    string temp;

    for(index=0; index<ast_nodes.size(); index++)
    {
        for(index1=0; index1<inline_function_names.size(); index1++)
        {
            if(ast_nodes[index].content == inline_function_names[index1])
            {
                if(ast_nodes[index].child.size() != q_argvs[index1])
                {
                    temp = "inline function has error q_argvs "+ast_nodes[index].content;
                    raise_error(temp, -1, -1);
                }
                else
                {
                    break;
                }
            }
        }
    }
}

void show_ast(int depth, int index_of_node)
{
    int index, index1;
    string s="";
    static ofstream output;



    for(index=0; index<depth+1; index++)
    {
        s+="|";
    }

    if(depth==0)
    {
        output.open("output_ast.txt");
        for(index=0; index<ast_nodes.size(); index++)
        {
            if(ast_nodes[index].parent == -1)
            {
                output << s << ast_nodes[index].content << " "  <<
                     ast_nodes[index].node_type << " " << index << endl;

                for(index1=0; index1<ast_nodes[index].child.size(); index1++)
                {
                    show_ast(depth+1, ast_nodes[index].child[index1]);
                }
            }
        }
        output.close();
    }
    else
    {
        output << setw(5) << index_of_node << ": " << s << ast_nodes[index_of_node].content << ": " << eges_types_string_comparison[ast_nodes[index_of_node].type_of_edge_parent]  <<
             ": " << node_types_comparison[ast_nodes[index_of_node].node_type] << " " <<
              ast_nodes[index_of_node].index_of_node_of_symbol_table << endl;

        for(index1=0; index1<ast_nodes[index_of_node].child.size(); index1++)
        {
            show_ast(depth+1, ast_nodes[index_of_node].child[index1]);
        }
    }

}

void crawler_ast_for_ST(ST_node& st_node_now, int ast_node_index, int index_of_var_now,
                        int index_of_label_now, int index_of_st_node)
{
    int index;
    int temp;
    bool is_it_arg;

    ast_nodes[ast_node_index].index_of_node_of_symbol_table = index_of_st_node;

    switch(ast_nodes[ast_node_index].type_of_edge_parent)
    {
        case IN_FUNCTION:
        {
            is_it_arg = 0;
        } break;

        default:
        {
            is_it_arg = 1;
        } break;
    }

    if(ast_nodes[ast_node_index].content == "#var")
    {
        for(index=0; index<ast_nodes[ast_node_index].child.size(); index++)
        {
            if(ast_nodes[ast_nodes[ast_node_index].child[index]].child.size() != 0)
            {
                temp = stod(ast_nodes[ast_nodes[ast_nodes[ast_node_index].child[index]].child[0]].content);

                if(temp<=0)
                {
                    raise_error("incorrect array size", -1, -1);
                }

                st_node_now.index_of_label.push_back(-1);

                if(is_it_arg == 1)
                {
                    st_node_now.index_of_arg.push_back(index_of_arg);
                    st_node_now.index_of_variable.push_back(-1);
                    index_of_arg+=temp;
                }
                else
                {
                    st_node_now.index_of_arg.push_back(-1);
                    st_node_now.index_of_variable.push_back(index_of_var_now);
                    index_of_var_now+=temp;
                }


                st_node_now.q_variables.push_back(temp);
                st_node_now.simbol_names.push_back(ast_nodes[ast_nodes[ast_node_index].child[index]].content);
                st_node_now.simbol_types.push_back(ST_VARIABLE_NAME);
            }
            else
            {
                st_node_now.index_of_label.push_back(-1);

                if(is_it_arg == 1)
                {
                    st_node_now.index_of_arg.push_back(index_of_arg);
                    st_node_now.index_of_variable.push_back(-1);
                    index_of_arg+=1;
                }
                else
                {
                    st_node_now.index_of_arg.push_back(-1);
                    st_node_now.index_of_variable.push_back(index_of_var_now);
                    index_of_var_now+=1;
                }

                st_node_now.q_variables.push_back(1);
                st_node_now.simbol_names.push_back(ast_nodes[ast_nodes[ast_node_index].child[index]].content);
                st_node_now.simbol_types.push_back(ST_VARIABLE_NAME);
            }
        }
    }
    else if(ast_nodes[ast_node_index].content == "@label")
    {
        st_node_now.index_of_label.push_back(index_of_label_now);
        st_node_now.index_of_variable.push_back(-1);
        st_node_now.index_of_arg.push_back(-1) ;
        st_node_now.q_variables.push_back(-1);
        st_node_now.simbol_names.push_back(ast_nodes[ast_nodes[ast_node_index].child[0]].content);
        st_node_now.simbol_types.push_back(ST_LABEL_NAME);

        index_of_label_now+=1;
    }

    for(index=0; index<ast_nodes[ast_node_index].child.size(); index++)
    {
        crawler_ast_for_ST(st_node_now, ast_nodes[ast_node_index].child[index], index_of_var_now,
                           index_of_label_now, index_of_st_node);
    }

}

void make_ST()
{
    int index, index1, index2, temp, index_of_var_now, index_of_label_now;
    ST_node st_node_now, st_node_first;

    st_node_first.parent=-1;

    for(index=0; index<ast_nodes.size(); index++)
    {
        if(ast_nodes[index].content == "#function")
        {
            st_node_first.index_of_label.push_back(-1);
            st_node_first.simbol_names.push_back(ast_nodes[index+1].content);
            st_node_first.simbol_types.push_back(ST_FUNCTION_NAME);
            st_node_first.q_variables.push_back(-1);
            st_node_first.index_of_variable.push_back(-1);
            st_node_first.index_of_arg.push_back(-1);
        }
    }

    st_nodes.push_back(st_node_first);

    for(index=0; index<ast_nodes.size(); index++)
    {
        if(ast_nodes[index].content == "#function")
        {
            st_node_now = st_node_first;
            st_node_now.parent = 0;

            index_of_var_now   = 0;
            index_of_label_now = 0;

            index_of_arg=0;

            crawler_ast_for_ST(st_node_now, index, 0, 0, st_nodes.size());

            st_nodes.push_back(st_node_now);
            st_nodes[0].child.push_back(st_nodes.size()-1);
        }
    }
}

void show_ST()
{
    int index, index1;

    for(index=0; index<st_nodes.size(); index++)
    {
        for(index1=0; index1<st_nodes[index].simbol_names.size(); index1++)
        {
            cout <<  st_nodes[index].simbol_names[index1] <<  " "
                 << types_of_identifers_for_symbol_table_comparison [st_nodes[index].simbol_types[index1]] << " "
                 <<  "index_of_var: " << st_nodes[index].index_of_variable[index1] << " "
                 <<  "index_of_arg: " << st_nodes[index].index_of_arg[index1] << " "
                 <<  "q_vars: " << st_nodes[index].q_variables[index1] << " "
                 << "index_of_label: " << st_nodes[index].index_of_label[index1] << endl;
        }

        cout << endl << "-----------------" << endl;
    }
}

void test_ast_with_st(int index_of_node)
{
    int index1, index2;
    string temp;

    switch(ast_nodes[index_of_node].node_type)
    {
        case VARIABLE:
        {
            for(index1=0; index1<st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names.size();
                index1++)
            {
                if(st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names[index1] ==
                   ast_nodes[index_of_node].content && st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_types[index1] ==
                   ST_VARIABLE_NAME)
                {
                    break;
                }
            }
            if(index1==st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names.size())
            {
                temp = "unknown id name " + ast_nodes[index_of_node].content;
                raise_error(temp, -1, -1);
            }
        } break;

        case FUNCTION:
        {
            for(index1=0; index1<st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names.size();
                index1++)
            {
                if(st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names[index1] ==
                   ast_nodes[index_of_node].content && st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_types[index1] ==
                   ST_FUNCTION_NAME)
                {
                    break;
                }
            }

            for(index2=0; index2<inline_function_names.size(); index2++)
            {
                if(ast_nodes[index_of_node].content ==
                   inline_function_names[index2])
                {
                    break;
                }
            }
            if(index1==st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names.size()
               && index2 == inline_function_names.size())
            {
                temp = "unknown function name " + ast_nodes[index_of_node].content;
                raise_error(temp, -1, -1);
            }
        } break;

        case LABEL_NAME:
        {
            for(index1=0; index1<st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names.size();
                index1++)
            {
                if(st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names[index1] ==
                   ast_nodes[index_of_node].content && st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_types[index1] ==
                   ST_LABEL_NAME)
                {
                    break;
                }
            }
            if(index1==st_nodes[ast_nodes[index_of_node].index_of_node_of_symbol_table].simbol_names.size())
            {
                temp = "unknown id name " + ast_nodes[index_of_node].content;
                raise_error(temp, -1, -1);
            }
        } break;

        default: break;
    }

    for(index2=0; index2<ast_nodes[index_of_node].child.size(); index2++)
    {
        test_ast_with_st(ast_nodes[index_of_node].child[index2]);
    }
}

void test_function_main()
{
    int index, main_flag=0;
    for(index=0; index<st_nodes[0].simbol_names.size(); index++)
    {
        if(st_nodes[0].simbol_names[index] == "main")
        {
            main_flag=1;
            break;
        }
    }

    if(main_flag==0)
    {
        raise_error("function main expected", -1, -1);
    }
}




/*int main()
{
    int index, index1;

    tokens = lexer();
    cout << "==================" << endl;
    parse_module();

    test_inline_functions_q_argvs();

    cout << "==================" << endl;

    show_ast(0, 0);

    cout << "==================" << endl;

    delete_fors_from_ast();

    show_ast(0, 0);

    cout << "==================" << endl;

    delete_whiles_from_ast();

    show_ast(0, 0);

    cout << "==================" << endl;

    make_ST();

    show_ST();

    show_ast(0, 0);

    cout << "==================" << endl;

    test_ast_with_st(0);



    return 0;
} */

