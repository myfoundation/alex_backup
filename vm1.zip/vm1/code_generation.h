#include <iostream>
#include "parser_and_lexer.h"

#define R_VAL 0
#define L_VAL 1

using namespace std;

struct labels_type
{
    int x;
    string name;
};

vector <string> commands_for_vm;

vector <string> names_of_if_labels;

int if_label_index=0;


int find_var_index(string var_name, int index_of_ast_node, int &is_it_arg)
{
    int index;
    string temp;
    for(index=0; index<st_nodes[ast_nodes[index_of_ast_node].index_of_node_of_symbol_table].simbol_names.size(); index++)
    {
        if(st_nodes[ast_nodes[index_of_ast_node].index_of_node_of_symbol_table].simbol_names[index] == var_name
           && st_nodes[ast_nodes[index_of_ast_node].index_of_node_of_symbol_table].simbol_types[index] == ST_VARIABLE_NAME)
        {
            if(st_nodes[ast_nodes[index_of_ast_node].index_of_node_of_symbol_table].index_of_variable[index] == -1)
            {
                is_it_arg = 1;
                return(st_nodes[ast_nodes[index_of_ast_node].index_of_node_of_symbol_table].index_of_arg[index]);
            }
            else
            {
                is_it_arg = 0;
                return(st_nodes[ast_nodes[index_of_ast_node].index_of_node_of_symbol_table].index_of_variable[index]);
            }

        }
    }
    temp = "unknown var name found " + var_name;
    raise_error(temp, -1, -1);
}

int get_q_argvs_in_function(string function_name)
{
    int index, index1, q_argvs = 0;
    for(index=0; index<st_nodes[0].simbol_names.size(); index++)
    {
        if(st_nodes[0].simbol_names[index] == function_name) // get name of function
        {
            for(index1=0; index1<st_nodes[st_nodes[0].child[index]].simbol_names.size(); index1++)
            {
                if(st_nodes[st_nodes[0].child[index]].simbol_types[index1] == VARIABLE &&
                   st_nodes[st_nodes[0].child[index]].index_of_arg[index1] != -1)
                {
                    q_argvs+=st_nodes[st_nodes[0].child[index]].q_variables[index1];
                }
            }
            break;
        }
    }
    return(q_argvs);
}

int get_q_vars_in_function(string function_name)
{
    int index, index1, q_vars = 0;
    for(index=0; index<st_nodes[0].simbol_names.size(); index++)
    {
        if(st_nodes[0].simbol_names[index] == function_name) // get name of function
        {
            for(index1=0; index1<st_nodes[st_nodes[0].child[index]].simbol_names.size(); index1++)
            {
                if(st_nodes[st_nodes[0].child[index]].simbol_types[index1] == VARIABLE &&
                   st_nodes[st_nodes[0].child[index]].index_of_variable[index1] != -1)
                {
                    q_vars+=st_nodes[st_nodes[0].child[index]].q_variables[index1];
                }
            }
            break;
        }
    }
    return(q_vars);
}

void create_commands_for_expression(int index_of_ast_node, int val_type = R_VAL)
{
    int index, var_index, is_it_arg, if_flag_first_if_child=0;
    string temp;

    vector <string> inline_function_names = {"+", "-", "*", "/", "=", "||", "&&", ">", "<", ">=", "<=", "==", "!=", "!",
                                             "@link", "@pointer", "@UNAR_MINUS", "#return", "#writeln", "#print", "@load", "#int_16", "#push"};

    vector <string> inline_special_function_names = {"@link", "@pointer", "#push"};

    vector <string> inline_function_comparison = {"+", "-", "*", "/", "write_by_top_stack", "+", "*", ">", "<", ">=", "<=", "==", "!=", "!",
                                                  "", "", "un_-", "return", "writeln_top_stack", "write_char_top_stack",
                                                  "load_by_top_stack", "int_16", ""};

    for(index=0; index<ast_nodes[index_of_ast_node].child.size(); index++)
    {

        if(if_flag_first_if_child == 0 && ast_nodes[index_of_ast_node].content == "#if"
           && ast_nodes[ast_nodes[index_of_ast_node].child[index]].type_of_edge_parent == IN_IF)
        {
            if_flag_first_if_child = 1;
            commands_for_vm.push_back("if_zero_goto_label");
            temp = "if_label";
            temp += to_string(if_label_index);
            commands_for_vm.push_back(temp);
            names_of_if_labels.push_back(temp);
            if_label_index+=1;
        }

        if((ast_nodes[index_of_ast_node].content == "="  && index==0)
           || ast_nodes[index_of_ast_node].content == "@pointer")
        {
            create_commands_for_expression(ast_nodes[index_of_ast_node].child[index], L_VAL);
        }
        else
        {
            create_commands_for_expression(ast_nodes[index_of_ast_node].child[index], R_VAL);
        }

        if(ast_nodes[index_of_ast_node].content == "#if"  &&
           index==ast_nodes[index_of_ast_node].child.size()-1)
        {
            if(names_of_if_labels.size()>0)
            {
                commands_for_vm.push_back("label");
                commands_for_vm.push_back(names_of_if_labels.back());
                names_of_if_labels.pop_back();
                if_flag_first_if_child = 0;
            }
            else
            {
                raise_error("error create code #if", -1, -1);
            }
        }
    }

    switch(ast_nodes[index_of_ast_node].node_type)
    {
        case VARIABLE:
        {
            if(ast_nodes[index_of_ast_node].child.size()>0)
            {
                if(val_type == L_VAL)
                {
                    var_index = find_var_index(ast_nodes[index_of_ast_node].content, index_of_ast_node, is_it_arg);
                    commands_for_vm.push_back("push");
                    commands_for_vm.push_back(INT_TO_MY_NUM(var_index));

                    commands_for_vm.push_back("+");

                    if(is_it_arg == 1)
                    {
                        commands_for_vm.push_back("load_pointer_to_arg_by_top_stack"); // it is arg
                    }
                    else
                    {
                        commands_for_vm.push_back("load_pointer_to_var_by_top_stack"); // it is in function
                    }
                }
                else
                {
                    var_index = find_var_index(ast_nodes[index_of_ast_node].content, index_of_ast_node, is_it_arg);
                    commands_for_vm.push_back("push");
                    commands_for_vm.push_back(INT_TO_MY_NUM(var_index));

                    commands_for_vm.push_back("+");

                    if(is_it_arg == 1)
                    {
                        commands_for_vm.push_back("load_arg_by_top_stack"); // it is arg
                    }
                    else
                    {
                        commands_for_vm.push_back("load_var_by_top_stack"); // it is in function
                    }
                }
            }
            else
            {
                if(val_type == L_VAL)
                {
                    var_index = find_var_index(ast_nodes[index_of_ast_node].content, index_of_ast_node, is_it_arg);

                    if(is_it_arg == 1)
                    {
                        commands_for_vm.push_back("load_pointer_to_arg_by_command"); // it is arg
                    }
                    else
                    {
                        commands_for_vm.push_back("load_pointer_to_var_by_command"); // it is in function
                    }

                    commands_for_vm.push_back(INT_TO_MY_NUM(var_index));
                }
                else
                {
                    var_index = find_var_index(ast_nodes[index_of_ast_node].content, index_of_ast_node, is_it_arg);

                    if(is_it_arg == 1)
                    {
                        commands_for_vm.push_back("load_arg_by_command"); // it is arg
                    }
                    else
                    {
                        commands_for_vm.push_back("load_var_by_command"); // it is in function
                    }

                    commands_for_vm.push_back(INT_TO_MY_NUM(var_index));
                }
            }
        } break;

        case CONSTANT:
        {
            commands_for_vm.push_back("push");
            commands_for_vm.push_back(ast_nodes[index_of_ast_node].content);
        } break;

        case FUNCTION:
        {
            for(index=0; index<inline_special_function_names.size(); index++)
            {
                if(ast_nodes[index_of_ast_node].content == inline_special_function_names[index])
                {
                    break;
                }
            }

            if(index != inline_special_function_names.size())
            {

            }
            else
            {
                for(index=0; index<inline_function_names.size(); index++)
                {
                    if(ast_nodes[index_of_ast_node].content == inline_function_names[index])
                    {
                        break;
                    }
                }

                if(index == inline_function_names.size())
                {
                    commands_for_vm.push_back("call");
                    commands_for_vm.push_back(INT_TO_MY_NUM(get_q_argvs_in_function(ast_nodes[index_of_ast_node].content)));
                    commands_for_vm.push_back(INT_TO_MY_NUM(get_q_vars_in_function(ast_nodes[index_of_ast_node].content)));
                    commands_for_vm.push_back("goto_label");

                    temp = "";
                    temp += "#function_label_";
                    temp += ast_nodes[index_of_ast_node].content;

                    commands_for_vm.push_back(temp);
                }
                else
                {
                    commands_for_vm.push_back(inline_function_comparison[index]);
                }
            }
        } break;

        case OTHER_NODE_TYPE:
        {
            if(ast_nodes[index_of_ast_node].content == "@goto")
            {
                commands_for_vm.push_back("goto_label");
                commands_for_vm.push_back(ast_nodes[ast_nodes[index_of_ast_node].child[0]].content);
            }
            else if(ast_nodes[index_of_ast_node].content == "@label")
            {
                commands_for_vm.push_back("label");
                commands_for_vm.push_back(ast_nodes[ast_nodes[index_of_ast_node].child[0]].content);
            }
        } break;
    }
}

void generate_code()
{
    int index, index1;
    string temp;

    commands_for_vm.push_back("call");
    commands_for_vm.push_back(INT_TO_MY_NUM(get_q_argvs_in_function("main")));
    commands_for_vm.push_back(INT_TO_MY_NUM(get_q_vars_in_function("main")));
    commands_for_vm.push_back("goto_label");
    commands_for_vm.push_back("#function_label_main");
    commands_for_vm.push_back("halt");

    for(index=0; index<ast_nodes[0].child.size(); index++)
    {
        commands_for_vm.push_back("label");

        temp = "";
        temp += "#function_label_";
        temp += ast_nodes[ast_nodes[ast_nodes[0].child[index]].child[0]].content;
        commands_for_vm.push_back(temp);

        for(index1=0; index1<ast_nodes[ast_nodes[0].child[index]].child.size(); index1++)
        {
            if(ast_nodes[ast_nodes[ast_nodes[0].child[index]].child[index1]].type_of_edge_parent == IN_FUNCTION)
            {
                if(ast_nodes[ast_nodes[ast_nodes[0].child[index]].child[index1]].content != "#var")
                {
                    create_commands_for_expression(ast_nodes[ast_nodes[0].child[index]].child[index1]);
                }
            }
        }
    }
}

void show_commands()
{
    int index;
    ofstream output;
    output.open("output_commands.txt");
    output << "--------------------" << endl;

    for(index=0; index<commands_for_vm.size(); index++)
    {
        cout << setw(5) << index << ": " << commands_for_vm[index] << endl;
    }
    output.close();
}

void delete_labels_from_code()
{
    vector <labels_type> labels;
    labels_type label_now;
    int index, index1;
    for(index=0; index<commands_for_vm.size(); index++)
    {
        if(commands_for_vm[index] == "label")
        {
            label_now.x = index;
            label_now.name = commands_for_vm[index+1];
            labels.push_back(label_now);
            commands_for_vm.erase(commands_for_vm.begin()+index);
            commands_for_vm.erase(commands_for_vm.begin()+index);
            index -= 1;
        }
    }


    cout << "   labels:" << endl;
    for(index=0; index<labels.size(); index++)
    {
        cout << setw(5) << labels[index].x << " " << labels[index].name << endl;;
    }
    cout << "--------------" << endl;

    for(index=0; index<commands_for_vm.size(); index++)
    {
        if(commands_for_vm[index] == "goto_label"
           || commands_for_vm[index] == "if_zero_goto_label")
        {
            for(index1=0; index1<labels.size(); index1++)
            {
                if(labels[index1].name == commands_for_vm[index+1])
                {
                    break;
                }
            }

            if(commands_for_vm[index] == "goto_label")
            {
                commands_for_vm[index] = "jmp";
            }
            else if(commands_for_vm[index] == "if_zero_goto_label")
            {
                commands_for_vm[index] = "jmp_if_zero";
            }

            commands_for_vm[index+1] = INT_TO_MY_NUM(labels[index1].x - index);
        }
    }
}

/*int main()
{
    int index, index1;

    tokens = lexer();
    cout << "==================" << endl;
    parse_module();

    show_ast(0, 0);
    cout << "==================" << endl;

    test_inline_functions_q_argvs();

    cout << "==================" << endl;

    show_ast(0, 0);

    cout << "==================" << endl;

    delete_fors_from_ast();

    show_ast(0, 0);

    cout << "==================" << endl;

    delete_whiles_from_ast();

    show_ast(0, 0);

    cout << "==================" << endl;

    make_ST();

    show_ST();

    show_ast(0, 0);

    test_ast_with_st(0);

    test_function_main();

    cout << "@@@@@@@@@@@@@@@@@@@@@" << endl;


    generate_code();
    show_commands();

    cout << "@@@@@@@@@@@@@@@@@@@@@" << endl;

    delete_labels_from_code();
    show_commands();





    return 0;
}*/
