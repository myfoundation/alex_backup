// LIBRARIES ////////

#include <iostream>
#include <vector>
#include <string>

/////////////////////

// DEFENITIONS //////

#define MY_NUM     string
#define SIGN_PLUS  1
#define SIGN_MINUS 0
#define Q_ITER_DIV 30

/////////////////////

// NAMESPACE ////////

using namespace std;

/////////////////////

// PROTOTYPES ///////

MY_NUM MY_NUM_ADD (MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
int char_to_num (char ch);
char num_to_char (int num);
MY_NUM mult_ten(MY_NUM MY_NUM_F);
MY_NUM mult_ten_times(MY_NUM MY_NUM_F, int n);
MY_NUM div_ten(MY_NUM MY_NUM_F);
string plus_or_minus(MY_NUM MY_NUM_1, MY_NUM MY_NUM_2, MY_NUM reslt);
MY_NUM MY_NUM_MULT(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
bool is_this_my_num(string n);
int my_num_to_int(MY_NUM n);
MY_NUM INT_TO_MY_NUM(int n);
bool MY_NUM_NOT_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
bool MY_NUM_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
bool MY_NUM_BIGGER(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
bool MY_NUM_BIGGER_OR_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
bool MY_NUM_LESS(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);
bool MY_NUM_LESS_OR_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S);

/////////////////////

int flag_div_by_zero = 0;

bool is_this_my_num(string n)
{
    int dot_flag=0, i, i1;
    string nums = "0123456789";
    for(i=0; i<n.length(); i++)
    {
        if(i==0)
        {
            if(!(n[0] == '+' || n[0] == '-'))
            {
                return(0);
            }
        }
        else
        {
            for(i1=0; i1<nums.length(); i1++)
            {
                if(nums[i1] == n[i])
                {
                    break;
                }
            }
            if(i1 == nums.length())
            {
                if(n[i] == '.')
                {
                    if(dot_flag == 1)
                    {
                        return(0);
                    }
                    dot_flag = 1;
                }
                else
                {
                    return(0);
                }
            }
        }
    }

    if(dot_flag == 0)
    {
        return(0);
    }
    return(1);

}

int char_to_num (char ch)
{
    string a = "0123456789";
    int i;
    for (i=0; i<10; i++)
    {
        if (a[i] == ch)
        {
            return i;
        }
    }
}

char num_to_char (int num)
{
    string a = "0123456789";
    return(a[num]);
}

int my_num_to_int(MY_NUM n)
{
    int i;
    int res=0;
    for(i=1; i<n.length(); i++)
    {
        if(n[i] == '.')
        {
            break;
        }
        res*=10;
        res+=char_to_num(n[i]);
    }

    if(n[0] == '-')
    {
        res*=-1;
    }
    return(res);
}

MY_NUM mult_ten(MY_NUM MY_NUM_F)
{
    MY_NUM res;
    int i;

    MY_NUM_F.insert(MY_NUM_F.length(), "0");

    for(i=0; i<MY_NUM_F.length(); i++)
    {
        if(MY_NUM_F[i] == '.')
        {
            res+=MY_NUM_F[i+1];
            res+=".";
            i+=1;
        }
        else
        {
            res+=MY_NUM_F[i];
        }
    }
    return(res);
}

MY_NUM mult_ten_times(MY_NUM MY_NUM_F, int n)
{
    MY_NUM res;
    int i;
    for (i = 0; i < n; i++)
    {
        MY_NUM_F.insert(MY_NUM_F.length(), "0");
    }
    return(MY_NUM_F);
}

MY_NUM div_ten(MY_NUM MY_NUM_F)
{
    MY_NUM res;
    int i;

    MY_NUM_F.insert(1, "0");

    for(i=0; i<MY_NUM_F.length(); i++)
    {
        if(MY_NUM_F[i] == '.')
        {
            res.insert(res.length()-1, ".");
        }
        else
        {
            res+=MY_NUM_F[i];
        }
    }
    return(res);
}

string plus_or_minus(MY_NUM MY_NUM_1, MY_NUM MY_NUM_2, MY_NUM reslt)
{
    if ((MY_NUM_1[0] == '+' && MY_NUM_2[0] == '-') || (MY_NUM_1[0] == '-' && MY_NUM_2[0] == '+'))
    {
        reslt.insert(0, "-");
    }
    else
    {
        reslt.insert(0, "+");
    }
    return reslt;
}

MY_NUM MY_NUM_NORMAL_MODE(MY_NUM MY_NUM_F)
{
    int i, i1, i2;
    MY_NUM res = "";

    for(i=MY_NUM_F.length()-1; i>=0; i--)
    {
        if(MY_NUM_F[i] != '0')
        {
            break;
        }
    }

    for(i1=1; i1<MY_NUM_F.length(); i1++)
    {
        if(MY_NUM_F[i1] != '0')
        {
            break;
        }
    }

    res+=MY_NUM_F[0];
    for(i2=i1; i2<=i+1; i2++)
    {
        res+=MY_NUM_F[i2];
    }

    if(res[1] == '.')
    {
    res.insert(1, "0");
    }

    return(res);

}

MY_NUM MY_NUM_DIV (MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{

    MY_NUM delimoe, delitel, chastnoe, temp, pribavlenie_k_chastnomu;
    int i, exp_counter;

    delimoe = MY_NUM_F;
    delimoe[0] = '+';

    delitel = MY_NUM_S;
    delitel[0] = '+';

    chastnoe = "+0.0";

    for(i=0; i<Q_ITER_DIV; i++)
    {
        delimoe = mult_ten(delimoe);
    }

    if(MY_NUM_NORMAL_MODE(MY_NUM_S) == "+0.0" || MY_NUM_NORMAL_MODE(MY_NUM_S) == "-0.0")
    {
        flag_div_by_zero = 1;
        if(!(MY_NUM_NORMAL_MODE(MY_NUM_F) == "+0.0" || MY_NUM_NORMAL_MODE(MY_NUM_F) == "-0.0"))
        {
            return "+0.0";
        }
    return "+1.0";
    }


    for(exp_counter = delimoe.length(); exp_counter>=0; exp_counter-=1)
    {
        while(delimoe[0] == '+')
        {

            temp = delitel;
            pribavlenie_k_chastnomu = "+1.0";

            for(i=0; i<exp_counter; i++)
            {
                temp =  mult_ten(temp);
                pribavlenie_k_chastnomu = mult_ten(pribavlenie_k_chastnomu);
            }

            temp[0] = '-';

            delitel = MY_NUM_NORMAL_MODE(delitel);
            delimoe = MY_NUM_NORMAL_MODE(delimoe);
            temp    = MY_NUM_NORMAL_MODE(temp);

            //cout << "temp: " << temp << endl;
            //cout << "delimoe: " << delimoe << endl;
            //cout << "delitel: " << delitel << endl;

            pribavlenie_k_chastnomu = MY_NUM_NORMAL_MODE(pribavlenie_k_chastnomu);

            delimoe = MY_NUM_ADD(delimoe, temp);
            chastnoe = MY_NUM_ADD(chastnoe, pribavlenie_k_chastnomu);
        }

// one iteration back
        temp = delitel;
        pribavlenie_k_chastnomu = "-1.0";

        for(i=0; i<exp_counter; i++)
        {
            temp =  mult_ten(temp);
            pribavlenie_k_chastnomu = mult_ten(pribavlenie_k_chastnomu);
        }

        temp[0] = '+';

        delimoe = MY_NUM_ADD(delimoe, temp);
        chastnoe = MY_NUM_ADD(chastnoe, pribavlenie_k_chastnomu);
    }

    for(i=0; i<Q_ITER_DIV; i++)
    {
       chastnoe = div_ten(chastnoe);
    }

    chastnoe = MY_NUM_NORMAL_MODE(chastnoe);


    if(MY_NUM_F[0] == '+' && MY_NUM_S[0] == '+')
    {
        chastnoe[0] = '+';
    }
    else if(MY_NUM_F[0] == '-' && MY_NUM_S[0] == '-')
    {
        chastnoe[0] = '+';
    }
    else
    {
        chastnoe[0] = '-';
    }
return(chastnoe);
}


MY_NUM MY_NUM_ADD (MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    int q_num_order_f,q_num_order_s;
    int q_num_mant_f, q_num_mant_s;
    int sign_f, sign_s;
    int i;
    int i1;
    int temp;
    int inh;
    MY_NUM res, final_res;
    int flag_of_it_is_zero;
    string t;

    for (i=1; i<MY_NUM_F.length(); i++)
    {
       if (MY_NUM_F[i]=='.')
       {
           break;
       }
    }

    q_num_order_f=i-1;
    q_num_mant_f = MY_NUM_F.length() - i - 1;

    for (i=1; i<MY_NUM_S.length(); i++)
    {
       if (MY_NUM_S[i]=='.')
       {
           break;
       }
    }

    q_num_order_s=i-1;
    q_num_mant_s = MY_NUM_S.length() - i - 1;

    if (q_num_order_f == q_num_order_s)
        {}
    else if (q_num_order_f > q_num_order_s)
    {
        for (i=0; i<q_num_order_f - q_num_order_s; i++)
        {
            MY_NUM_S.insert (1, "0");
        }
    }
    else
    {
        for (i=0; i<q_num_order_s - q_num_order_f; i++)
        {
            MY_NUM_F.insert (1, "0");
        }
    }


    if (q_num_mant_f == q_num_mant_s)
        {}
    else if (q_num_mant_f > q_num_mant_s)
    {
        for (i=0; i<q_num_mant_f - q_num_mant_s; i++)
        {
            MY_NUM_S +="0";
        }
    }
    else
    {
        for (i=0; i<q_num_mant_s - q_num_mant_f; i++)
        {
            MY_NUM_F +="0";
        }
    }

    if((MY_NUM_F[0] == '+' && MY_NUM_S[0] == '+')
       || (MY_NUM_F[0] == '-' && MY_NUM_S[0] == '-'))
    {
        inh = 0;

        for (i=MY_NUM_F.length()-1; i>=1; i--)
        {
            if (MY_NUM_F[i]!='.')
            {
                temp = (char_to_num(MY_NUM_F[i]) + char_to_num(MY_NUM_S[i]) + inh) % 10;
                inh = (char_to_num(MY_NUM_F[i]) + char_to_num(MY_NUM_S[i]) + inh) / 10;
                t="";
                t+=num_to_char(temp);
                res.insert(0, t);
            }
            else
            {
                res.insert(0, ".");
            }
        }

        temp = inh;
        t="";
        t+=num_to_char(temp);
        res.insert(0, t);

        if(MY_NUM_F[0] == '+' && MY_NUM_S[0] == '+')
        {
            res.insert(0, "+");
        }
        else
        {
            res.insert(0, "-");
        }

    }
    else
    {
        for(i=1; i<MY_NUM_F.length(); i++)
        {
            if(MY_NUM_F[i] != '0' && MY_NUM_F[i] != '.')
            {
                if(char_to_num(MY_NUM_F[i]) > char_to_num(MY_NUM_S[i]))
                {
                    temp=1;
                    break;
                }

            }

            if(MY_NUM_S[i] != '0' && MY_NUM_S[i] != '.')
            {
                if(char_to_num(MY_NUM_S[i]) > char_to_num(MY_NUM_F[i]))
                {
                    temp=-1;
                    break;
                }

            }
        }

        inh=0;
        if(temp==1)
        {
            for (i=MY_NUM_F.length()-1; i>=1; i--)
            {
                if (MY_NUM_F[i]!='.')
                {
                    temp = (char_to_num(MY_NUM_F[i]) - char_to_num(MY_NUM_S[i]) - inh);

                    if(temp<0)
                    {
                        temp+=10;
                        inh=1;
                    }
                    else
                    {
                        inh=0;
                    }

                    t="";
                    t+=num_to_char(temp);
                    res.insert(0, t);
                }
                else
                {
                    res.insert(0, ".");
                }
            }

            if(MY_NUM_F[0] == '+')
            {
                res.insert(0, "+");
            }
            else
            {
                res.insert(0, "-");
            }

        }
        else
        {
            for (i=MY_NUM_F.length()-1; i>=1; i--)
            {
                if (MY_NUM_F[i]!='.')
                {
                    temp = (char_to_num(MY_NUM_S[i]) - char_to_num(MY_NUM_F[i]) - inh);

                    if(temp<0)
                    {
                        temp+=10;
                        inh=1;
                    }
                    else
                    {
                        inh=0;
                    }

                    t="";
                    t+=num_to_char(temp);
                    res.insert(0, t);
                }
                else
                {
                    res.insert(0, ".");
                }
            }

            if(MY_NUM_S[0] == '+')
            {
                res.insert(0, "+");
            }
            else
            {
                res.insert(0, "-");
            }
        }
    }

    flag_of_it_is_zero = 1;

    for(i=0; i<res.length(); i++)
        {
        if(res[i] != '.' && res[i] != '+' && res[i] != '-' && res[i] != '0')
            {
            flag_of_it_is_zero = 0;
            }
        }

    if(flag_of_it_is_zero == 1)
        {
        res[0] = '+';
        }
    return MY_NUM_NORMAL_MODE(res);
}

MY_NUM MY_NUM_MIN (MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    if(MY_NUM_S[0] == '+')
    {
        MY_NUM_S[0] = '-';
    }
    else
    {
        MY_NUM_S[0] = '+';
    }

return(MY_NUM_ADD(MY_NUM_F, MY_NUM_S));
}

MY_NUM MY_NUM_UNAR_MIN (MY_NUM MY_NUM_F)
{
    if(MY_NUM_F[0] == '+')
    {
        MY_NUM_F[0] = '-';
    }
    else
    {
        MY_NUM_F[0] = '+';
    }

return(MY_NUM_NORMAL_MODE(MY_NUM_F));
}

MY_NUM MY_NUM_MULT(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM MY_NUM_F_St = MY_NUM_F;
    MY_NUM MY_NUM_S_St = MY_NUM_S;
    MY_NUM res;
    int temp;
    int inh = 0;
    int n = 1;
    int l = 0;
    int m = 0;
    MY_NUM result = "+0.0";
    string t;
    vector <MY_NUM> array;
    // array.push_back()
    //�������� 1 ����� �� 2
    int e1 = 0;
    int e2 = 0;
    if ((MY_NUM_NORMAL_MODE(MY_NUM_F) == "+0.0" || MY_NUM_NORMAL_MODE(MY_NUM_F) == "-0.0") ||
        (MY_NUM_NORMAL_MODE(MY_NUM_S) == "+0.0" || MY_NUM_NORMAL_MODE(MY_NUM_S) == "-0.0"))
    {
        result = "+0.0";
        return result;
    }
    MY_NUM_F.erase(0, 1);
    MY_NUM_S.erase(0, 1);
    for (int i = MY_NUM_F.length()-1; i >= 0; i--)
    {
        if (MY_NUM_F[i] == '.')
        {
            e1 = MY_NUM_F.length() - i - 1;
            MY_NUM_F.erase(i, 1);
            break;
        }
    }
    for (int i = MY_NUM_S.length()-1; i >=0; i--)
    {
        if (MY_NUM_S[i] == '.')
        {
            e2 = MY_NUM_S.length() - i - 1;
            MY_NUM_S.erase(i, 1);
            break;
        }
    }
    int e = e1 + e2;
        for (int a = MY_NUM_F.length() - 1; a >= 0; a--)
        {
            inh = 0;
            for (int b = MY_NUM_S.length() - 1; b >= 0; b--)
            {
                temp = 0;
                temp = (char_to_num(MY_NUM_F[a]) * char_to_num(MY_NUM_S[b]) + inh) % 10;
                inh = (char_to_num(MY_NUM_F[a]) * char_to_num(MY_NUM_S[b]) + inh) / 10;
                t = "";
                t += num_to_char(temp);
                res.insert(0, t);
            }
            temp = inh;
            t = "";
            t += num_to_char(temp);
            res.insert(0, t);
            res = mult_ten_times(res,MY_NUM_F.length()-1 -a);
            array.push_back(res);
            res = "";
        }
        for (int q = 0; q < array.size(); q++)
        {
            array[q] += ".0";
            array[q].insert(0, "+");
            result = MY_NUM_ADD(result, array[q]);
        }
    result.erase(0, 1);
    result = plus_or_minus(MY_NUM_F_St, MY_NUM_S_St, result);
    result = MY_NUM_NORMAL_MODE(result);

    for (int i = 0; i < e; i++)
    {
        result = div_ten(result);
    }

    result = MY_NUM_NORMAL_MODE(result);
    return result;
}

bool MY_NUM_BIGGER(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM temp;
    temp = MY_NUM_MIN(MY_NUM_F, MY_NUM_S);

    if(temp == "+0.0" || temp == "-0.0")
    {
        return 0;
    }

    if(temp[0] == '+')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool MY_NUM_BIGGER_OR_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM temp;
    temp = MY_NUM_MIN(MY_NUM_F, MY_NUM_S);

    if(temp == "+0.0" || temp == "-0.0")
    {
        return 1;
    }

    if(temp[0] == '+')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool MY_NUM_LESS(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM temp;
    temp = MY_NUM_MIN(MY_NUM_F, MY_NUM_S);

    if(temp == "+0.0" || temp == "-0.0")
    {
        return 0;
    }

    if(temp[0] == '-')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool MY_NUM_LESS_OR_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM temp;
    temp = MY_NUM_MIN(MY_NUM_F, MY_NUM_S);

    if(temp == "+0.0" || temp == "-0.0")
    {
        return 1;
    }

    if(temp[0] == '-')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


bool MY_NUM_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM temp;
    temp = MY_NUM_MIN(MY_NUM_F, MY_NUM_S);

    if(temp == "+0.0" || temp == "-0.0")
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool MY_NUM_NOT_EQUAL(MY_NUM MY_NUM_F, MY_NUM MY_NUM_S)
{
    MY_NUM temp;
    temp = MY_NUM_MIN(MY_NUM_F, MY_NUM_S);

    if(temp == "+0.0" || temp == "-0.0")
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

MY_NUM INT_TO_MY_NUM(int n)
{
    MY_NUM res="";
    if(n>=0)
    {
        res += "+";
        res += to_string(n);
        res +=".0";
    }
    else
    {
        res += to_string(n);
        res+=".0";
    }
    return(res);
}
