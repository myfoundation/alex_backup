#include "DOSEmu.h"
#include "texturtes.h"
#include "KEY_BOARD.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <conio.h>
#include <time.h>
#include <math.h>

#define SCREEN_WIDTH  1024
#define SCREEN_HEIGHT 768

// for line function
#define LINE_WITH_BORDERS    1
#define LINE_WITHOUT_BORDERS 2

#define MAP_WIDTH   11
#define MAP_HEIGHT  11

#define INTERSECTION_TYPE_X 0
#define INTERSECTION_TYPE_Y 1

using namespace std;

void draw_line_from_picture(int line_x, int line_length, int x_index_picture, int picture_index);

const int length_cell = 50;

int _map[MAP_WIDTH*MAP_HEIGHT]=
{
//  0  1  2  3  4  5  6  7  8  9  10
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 1
    0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, // 2
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 3
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 4
    0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, // 5
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, // 6
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 7
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 8
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 9
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 10
};

int _texture_map_x[(MAP_WIDTH+2)*(MAP_HEIGHT+2)]=
{
//  0  1  2  3  4  5  6  7  8  9  10 11 12
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 1
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 2
    0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, // 3
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 4
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 5
    0, 0, 0, 2, 0, 1, 0, 0, 0, 2, 0, 0, 0, // 6
    0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, // 7
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 8
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 9
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 10
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 11
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 12
};

int _texture_map_y[(MAP_WIDTH+2)*(MAP_HEIGHT+2)]=
{
//  0  1  2  3  4  5  6  7  8  9  10 11 12
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // 0
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 1
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 2
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 3
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 4
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 5
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 6
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 7
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 8
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 9
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 10
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, // 11
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // 12
};


int get_value_from_map(int x, int y)
{
    if(x<0 || y<0 || x>=MAP_WIDTH || y>=MAP_WIDTH)
    {
        return (1);
    }
    return (_map[x+y*MAP_WIDTH]);
}

void draw_squar(int x, int y, int length, RGB_COLOR color)
{
    int i_x, i_y;
    for(i_x=0; i_x<length; i_x++)
    {
        for(i_y=0; i_y<length; i_y++)
        {
            set_pixel_video_buf(i_x+x, i_y+y, color);
        }
    }
}

void vertical_line(int x, int y, int y1, RGB_COLOR color)
{
    int index;
    for(index=min(y, y1); index<=max(y, y1); index++)
    {
        set_pixel_video_buf(x, index, color);
    }
}

void line(int _x, int _y, int _x1, int _y1, RGB_COLOR color, int mode = LINE_WITH_BORDERS)
{

int x=min(_x, _x1);
int y=min(_y, _y1);

int x1=max(_x, _x1);
int y1=max(_y, _y1);

bool invers_mode = false;

if(!((x==_x && y==_y) || (x==_x1 && y==_y1)))
    {
    invers_mode = true;
    }

//invers_mode = false;

int index;

int x_now, y_now;
int x_old, y_old;

if((x1-x)!=0)
    {
    for(index=0; index<=(x1-x); index++)
        {
        x_now = x+index;
        y_now = y+round(((y1-y)*index/(double)(x1-x)));

        if(mode == LINE_WITH_BORDERS)
            {
            if((x1-x)>=(y1-y))
                {
                if((x_now!=x_old) && (y_now!=y_old) && (index!=0))
                    {
                    if(invers_mode == false)
                        {
                        set_pixel_video_buf(x_old+1, y_old, color);
                        }
                    else
                        {
                        set_pixel_video_buf(x_old+1, y1-y_old+y, color);
                        }
                    }
                }
            }

        if(invers_mode == false)
            {
            set_pixel_video_buf(x_now, y_now, color);
            }
        else
            {
            set_pixel_video_buf(x_now, y1-y_now+y, color);
            }


        x_old = x_now;
        y_old = y_now;
        }
    }

if((y1-y)!=0)
    {
    for(index=0; index<=(y1-y); index++)
        {
        x_now = x+round(((x1-x)*index/(double)(y1-y)));
        y_now = y+index;

        if(mode == LINE_WITH_BORDERS)
            {
            if((x1-x)<(y1-y))
                {
                if((x_now!=x_old) && (y_now!=y_old) && (index!=0))
                    {
                    if(invers_mode == false)
                        {
                        set_pixel_video_buf(x_old+1, y_old, color);
                        }
                    else
                        {
                        set_pixel_video_buf(x_old+1, y1-y_old+y, color);
                        }
                    }
                }
            }

        if(invers_mode == false)
            {
            set_pixel_video_buf(x_now, y_now, color);
            }
        else
            {
            set_pixel_video_buf(x_now, y1-y_now+y, color);
            }

        x_old = x_now;
        y_old = y_now;
        }
    }
}

double ray_length(double player_x, double player_y, double angle, double &length_intersection,
                  int &intersection_type, int &index_texture_map)
{
    RGB_COLOR color1, color2;

    double x_ray, y_ray, length_ray_x, length_ray_y,
           length_intersection_x, length_intersection_y;

    int x_map_coeff_x_inersecion, y_map_coeff_x_inersecion,
        x_map_coeff_y_inersecion, y_map_coeff_y_inersecion,
        index_texture_map_x, index_texture_map_y;

    color1.red   = 100;
    color1.green = 100;
    color1.blue  = 100;

    color2.red   = 255;
    color2.green = 255;
    color2.blue  = 255;

    while(angle<0)
    {
        angle+=2*3.14159;
    }

    while(angle>2*3.14159)
    {
        angle-=2*3.14159;
    }

    if(angle>=0 && angle<=3.14159/2)
    {
        x_map_coeff_x_inersecion=0;
        x_map_coeff_y_inersecion=0;
        y_map_coeff_x_inersecion=0;
        y_map_coeff_y_inersecion=0;
    }
    else if(angle>3.14159/2 && angle<=3.14159)
    {
        x_map_coeff_x_inersecion=0;
        x_map_coeff_y_inersecion=0;
        y_map_coeff_x_inersecion=-1;
        y_map_coeff_y_inersecion=0;
    }
    else if(angle>3.14159 && angle<=3*3.14159/2)
    {
        x_map_coeff_x_inersecion=0;
        x_map_coeff_y_inersecion=-1;
        y_map_coeff_x_inersecion=-1;
        y_map_coeff_y_inersecion=0;
    }
    else if(angle>3*3.14159/2 && angle<=2*3.14159)
    {
        x_map_coeff_x_inersecion=0;
        x_map_coeff_y_inersecion=-1;
        y_map_coeff_x_inersecion=0;
        y_map_coeff_y_inersecion=0;
    }

// OX intersection

    if(abs(tan(angle))>100000)
    {
        if(angle>3.14159/2.0 && angle<3*3.14159/2.0)
        {
            y_ray = floor(player_y);
            x_ray = player_x + (floor(player_y) - player_y)*100000;
        }
        else
        {
            y_ray = ceil(player_y);
            x_ray = player_x + (ceil(player_y) - player_y)*100000;
        }

    }
    else if(abs(tan(angle))<0.00001)
    {
        if(angle>3.14159/2.0 && angle<3*3.14159/2.0)
        {
            y_ray = floor(player_y);
            x_ray = player_x + (floor(player_y) - player_y)*0.00001;
        }
        else
        {
            y_ray = ceil(player_y);
            x_ray = player_x + (ceil(player_y) - player_y)*0.00001;
        }

    }
    else
    {
        if(angle>3.14159/2.0 && angle<3*3.14159/2.0)
        {
            y_ray = floor(player_y);
            x_ray = player_x + (floor(player_y) - player_y)*tan(angle);
        }
        else
        {
            y_ray = ceil(player_y);
            x_ray = player_x + (ceil(player_y) - player_y)*tan(angle);
        }

    }

    /*cout << y_ray << endl;
    line(player_x*length_cell, player_y*length_cell, x_ray*length_cell,
        y_ray*length_cell, color1);
    show_video_buf();
    cout << player_x*length_cell << " " << player_y*length_cell << " " <<
        x_ray*length_cell << " " << y_ray*length_cell << endl;
    getch();*/

    while(get_value_from_map((int)x_ray+x_map_coeff_x_inersecion, (int)y_ray+y_map_coeff_x_inersecion) == 0)
    {
        if(angle>3.14159/2.0 && angle<3*3.14159/2.0)
        {
            y_ray-=1;
        }
        else
        {
            y_ray+=1;
        }

        if(abs(tan(angle))>100000)
        {
            x_ray+=100000;
        }
        else
        {

            if(angle>3.14159/2.0 && angle<3*3.14159/2.0)
            {
                x_ray-=tan(angle);
            }
            else
            {
                x_ray+=tan(angle);
            }
        }

        /*line(player_x*length_cell, player_y*length_cell, x_ray*length_cell,
            y_ray*length_cell, color1);
        show_video_buf();
        cout << player_x*length_cell << " " << player_y*length_cell << " " <<
            x_ray*length_cell << " " << y_ray*length_cell << endl;
        getch();*/
    }

    length_ray_x = sqrt((y_ray - player_y)*(y_ray - player_y) + (x_ray - player_x)*(x_ray - player_x));
    length_intersection_x = (double)x_ray - floor(x_ray);
    index_texture_map_x = (int)x_ray+1+x_map_coeff_x_inersecion+((int)y_ray+y_map_coeff_x_inersecion+1)*(MAP_WIDTH+2);

// OY intersection

    if(abs(tan(angle))>10000)
    {
        if(angle>3.14159 && angle<2*3.14159)
        {
            x_ray = floor(player_x);
            y_ray = player_y + (floor(player_x) - player_x)*1/10000;
        }
        else
        {
            x_ray = ceil(player_x);
            y_ray = player_y + (ceil(player_x) - player_x)*1/10000;
        }

    }
    else if(abs(tan(angle))<0.001)
    {
        if(angle>3.14159 && angle<2*3.14159)
        {
            x_ray = floor(player_x);
            y_ray = player_y + (floor(player_x) - player_x)*1/0.001;
        }
        else
        {
            x_ray = ceil(player_x);
            y_ray = player_y + (ceil(player_x) - player_x)*1/0.001;
        }

    }
    else
    {
        if(angle>3.14159 && angle<2*3.14159)
        {
            x_ray = floor(player_x);
            y_ray = player_y + (floor(player_x) - player_x)*1/tan(angle);
        }
        else
        {
            x_ray = ceil(player_x);
            y_ray = player_y + (ceil(player_x) - player_x)*1/tan(angle);
        }

    }

/*    line(player_x*length_cell, player_y*length_cell, x_ray*length_cell,
        y_ray*length_cell, color1);
    cout << player_x*length_cell << " " << player_y*length_cell << " " <<
        x_ray*length_cell << " " << y_ray*length_cell << endl;

    show_video_buf();
    getch();*/

    while(get_value_from_map((int)x_ray+x_map_coeff_y_inersecion, (int)y_ray+y_map_coeff_y_inersecion) == 0)
    {
        if(abs(tan(angle))<0.00001)
        {
            y_ray+=1.0/0.00001;
        }
        else
        {
            if(angle>3.14159 && angle<2*3.14159)
            {
                y_ray-=1.0/tan(angle);
            }
            else
            {
                y_ray+=1.0/tan(angle);
            }
        }

        if(angle>3.14159 && angle<2*3.14159)
        {
            x_ray-=1;
        }
        else
        {
            x_ray+=1;
        }


       /* line(player_x*length_cell, player_y*length_cell, x_ray*length_cell,
            y_ray*length_cell, color1);
        cout << player_x*length_cell << " " << player_y*length_cell << " " <<
            x_ray*length_cell << " " << y_ray*length_cell << endl;

        show_video_buf();
        getch();*/
    }

    length_ray_y = sqrt((y_ray - player_y)*(y_ray - player_y) + (x_ray - player_x)*(x_ray - player_x));
    length_intersection_y = (double)y_ray - floor(y_ray);
    index_texture_map_y = (int)x_ray+1+x_map_coeff_y_inersecion+((int)y_ray+y_map_coeff_y_inersecion+1)*(MAP_WIDTH+2);

////////////////////////////////////////////////////

    /*line(player_x*length_cell, player_y*length_cell, player_x*length_cell+sin(angle)*min(length_ray_x, length_ray_y)*length_cell,
         player_y*length_cell+cos(angle)*min(length_ray_x, length_ray_y)*length_cell, color2);*/

    if(length_ray_x<length_ray_y)
    {
        length_intersection = length_intersection_x;
        intersection_type = INTERSECTION_TYPE_X;
        index_texture_map = index_texture_map_x;
    }
    else
    {
        length_intersection = length_intersection_y;
        intersection_type = INTERSECTION_TYPE_Y;
        index_texture_map = index_texture_map_y;
    }

    return(min(length_ray_x, length_ray_y));
}

void draw_map()
{

    RGB_COLOR color[2];
    int i_x, i_y;

    color[0].red   = 0;
    color[0].green = 0;
    color[0].blue  = 100;

    color[1].red   = 0;
    color[1].green = 100;
    color[1].blue  = 0;

    for(i_x=0; i_x<MAP_WIDTH; i_x++)
    {
        for(i_y=0; i_y<MAP_HEIGHT; i_y++)
        {
            draw_squar(i_x*length_cell, i_y*length_cell, length_cell, color[get_value_from_map(i_x, i_y)]);
        }
    }
}

void draw_world(double player_angle, double player_angle_offset,
                double player_x, double player_y)
{
    int length_line_now, index, index1,
        intersection_type, index_texture_map;

    double temp, length_intersection, distance, coeff=400;

    RGB_COLOR color1, color2;

    color1.red   = 255;
    color1.green = 255;
    color1.blue  = 255;

    color2.red   = 0;
    color2.green = 0;
    color2.blue  = 0;

    for(index=0; index<SCREEN_WIDTH; index++)
    {
        distance = ray_length(player_x, player_y, (player_angle)/SCREEN_WIDTH*index+player_angle_offset,
                              length_intersection, intersection_type, index_texture_map);

        for(index1=1; index1<=2; index1++)
        {
            temp =ray_length(player_x, player_y, (player_angle)/SCREEN_WIDTH*(index+1.0/index1)+player_angle_offset,
                             length_intersection, intersection_type, index_texture_map);

            if(temp>distance)
            {
               distance = temp;
            }
        }



        length_line_now = coeff/(distance*cos((player_angle)/SCREEN_WIDTH*index-player_angle/2));

        vertical_line(index, 0, SCREEN_HEIGHT-1, color2);
        //vertical_line(index, (SCREEN_HEIGHT-length_line_now-1)/2, (SCREEN_HEIGHT-length_line_now-1)/2 + length_line_now, color1);

        if(intersection_type == INTERSECTION_TYPE_X)
        {
            draw_line_from_picture(index, length_line_now, pictures[_texture_map_x[index_texture_map]].width*length_intersection,
                                   _texture_map_x[index_texture_map]);
        }
        else
        {
            draw_line_from_picture(index, length_line_now, pictures[_texture_map_y[index_texture_map]].width*length_intersection,
                                   _texture_map_y[index_texture_map]);
        }



        /*draw_map();

        line(player_x*length_cell, player_y*length_cell, player_x*length_cell+sin((player_angle)/SCREEN_WIDTH*index+player_angle_offset)*distance*length_cell,
             player_y*length_cell+cos((player_angle)/SCREEN_WIDTH*index+player_angle_offset)*distance*length_cell, color1);
        show_video_buf();*/

    }

    /*draw_map();
    for(index=0; index<SCREEN_WIDTH; index++)
    {
        distance = ray_length(player_x, player_y, (player_angle)/SCREEN_WIDTH*index+player_angle_offset,
                              length_intersection, intersection_type, index_texture_map);



        line(player_x*length_cell, player_y*length_cell, player_x*length_cell+sin((player_angle)/SCREEN_WIDTH*index+player_angle_offset)*distance*length_cell,
             player_y*length_cell+cos((player_angle)/SCREEN_WIDTH*index+player_angle_offset)*distance*length_cell, color1);
    }*/
}


void draw_line_from_picture(int line_x, int line_length, int x_index_picture, int picture_index)
{
    int i_y, index_picture_y;

    index_picture_y=0;
    for(i_y=(SCREEN_HEIGHT-line_length-1)/2; i_y<(SCREEN_HEIGHT-line_length-1)/2
        +line_length-1; i_y++)
    {
        set_pixel_video_buf(line_x, i_y, pictures[picture_index].points[
                            pictures[picture_index].width*
                            floor(((pictures[picture_index].height)* index_picture_y) / line_length)
                            +x_index_picture]);
        index_picture_y+=1;
        //cout << floor((pictures[picture_index].height* index_picture_y) / line_length) << endl;
        //cout << x_index_picture << endl;
    }
    //show_video_buf();
    //getch();
}

long CONTROLLER_8253_TICKS = 0;

void _interrupt _far Timer()
{
	// increment time for process variable, note: we can do this since on entry
	// DS points to global data segment
	CONTROLLER_8253_TICKS++;
} // end Timer

void Draw_Frame()
{
    static long PREV_TICK = -1;
    long is_draw	= 0;

    // test if this is first time
    if (PREV_TICK == -1)	PREV_TICK = CONTROLLER_8253_TICKS;
    else	// not first time
    {
       // have 1 tick past?
       if(is_draw   = (CONTROLLER_8253_TICKS - PREV_TICK)>=1)	PREV_TICK = CONTROLLER_8253_TICKS; // save new old time
    }

    static double player_angle=3.14159/3, player_angle_offset=0, player_x=6.5, player_y=4.5;
    static int index=0;

    if(!is_draw) return;

	// DRAW HERE

		/*draw_map();

		for(index=0; index<SCREEN_WIDTH; index++)
		{
			ray_length(player_x, player_y, (player_angle)/SCREEN_WIDTH*index+player_angle_offset);
		}*/

		//animate_pictures();

		//draw_map();
	draw_world(player_angle, player_angle_offset, player_x, player_y);
	show_video_buf();

	// key pressing ////////////////////////////////////////
	if(key_table[INDEX_RIGHT])
	{
		player_angle_offset+=0.1;

		if(player_angle_offset>=3.14159*2)
		{
			player_angle_offset-=3.14159*2;
		}
	}
	if(key_table[INDEX_LEFT])
	{
		player_angle_offset-=0.1;

		if(player_angle_offset<0)
		{
			player_angle_offset+=3.14159*2;
		}
	}
	if(key_table[INDEX_UP])
	{
		player_x+=sin(player_angle_offset+player_angle/2)*0.1;
		player_y+=cos(player_angle_offset+player_angle/2)*0.1;

		while(get_value_from_map((int)player_x, (int)player_y)==1 ||
		   get_value_from_map((int)(player_x+0.2), (int)player_y)==1 ||
		   get_value_from_map((int)(player_x-0.2), (int)player_y)==1 ||
		   get_value_from_map((int)(player_x), (int)(player_y+0.2))==1 ||
		   get_value_from_map((int)(player_x), (int)(player_y-0.2))==1)
		{
			player_x-=sin(player_angle_offset+player_angle/2)*0.1;
			player_y-=cos(player_angle_offset+player_angle/2)*0.1;
		}
	}
	if(key_table[INDEX_DOWN])
	{
		player_x-=sin(player_angle_offset+player_angle/2)*0.1;
		player_y-=cos(player_angle_offset+player_angle/2)*0.1;

		while(get_value_from_map((int)(player_x), (int)player_y)==1 ||
		   get_value_from_map((int)(player_x+0.2), (int)player_y)==1 ||
		   get_value_from_map((int)(player_x-0.2), (int)player_y)==1 ||
		   get_value_from_map((int)(player_x), (int)(player_y+0.2))==1 ||
		   get_value_from_map((int)(player_x), (int)(player_y-0.2))==1)
		{
			player_x+=sin(player_angle_offset+player_angle/2)*0.1;
			player_y+=cos(player_angle_offset+player_angle/2)*0.1;
		}
	}
// end of key pressing ////////////////////////////////////////
}

void main2()
{
    srand(time(0));

	_set_render_options(FALSE, RENDER_SCALE_VGA_SCREEN);
	_set_render_options(TRUE, RENDER_MANUAL_REDRAW);


	_setvideomode(_XRESTRUECOLOR);

    get_screen_parameters();
    init_video_buf();

    init_keybuff();

    init_picture();

    _dos_setvect(TIME_KEEPER_INT, (void *)Timer);
    Init_Timer(CONTROL_8253_TIMER_60HZ);

	while(1)
    {
		Draw_Frame();
    }
}
