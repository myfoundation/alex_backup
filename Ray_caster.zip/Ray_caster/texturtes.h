#include "my_graph.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <math.h>

#define SCREEN_WIDTH_FOR_SCR_EFFECT     120
#define SCREEN_HEIGTH_FOR_SCR_EFFECT    120

#define Q_COLORED_FIELDS 15

using namespace std;

struct picture_type
{
    int width, height;
    vector <RGB_COLOR> points;
} ;

struct picture_image_type
{
    int offset;
    RGB_COLOR color;
    vector <double> coeffs;
} ;

void show_picture();
void make_iteration_field(int num_field);

vector<picture_type> pictures;
vector<picture_image_type> picture_images;

vector <int> colored_fields_times_now   = {0, 400, 800, 1200, 1200, 1500, 1800, 2100, 2400, 2700,
                                           3000, 5300, 6600, 7900, 8200};

vector <int> colored_fields_times       = {5300, 5300, 5300, 5300, 5300, 5300, 5300, 5300,
                                           5300, 5300, 5300, 5300, 5300, 5300, 5300};

vector <double> colored_fields_intensity   = {1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.7, 0.9, 0.5, 0.7,
                                              0.5, 1, 0.5, 0.7, 0.5};


int field [SCREEN_WIDTH_FOR_SCR_EFFECT][SCREEN_HEIGTH_FOR_SCR_EFFECT][Q_COLORED_FIELDS];
int colored_field [SCREEN_WIDTH_FOR_SCR_EFFECT][SCREEN_HEIGTH_FOR_SCR_EFFECT][Q_COLORED_FIELDS];

void init_picture()
{
    const int q_images = 3;
    string filenames[q_images] = {"input1.txt", "input2.txt", "input3.txt"};
    int i_x, i_y, i_x1, i_y1, r, g, b, index;
    picture_type picture1;
    picture_image_type picture_image1;
    RGB_COLOR color[q_images], color2;
    ifstream input[q_images];

    /*color[0].red   = 0;
    color[0].green = 0;
    color[0].blue  = 100;

    color[1].red   = 200;
    color[1].green = 200;
    color[1].blue  = 200;*/

    /*picture1.width  = 100;
    picture1.height = 100;

    for(i_x=0; i_x<10; i_x++)
    {
        for(i_y=0; i_y<10; i_y++)
        {
            for(i_x1=0; i_x1<10; i_x1++)
            {
                for(i_y1=0; i_y1<10; i_y1++)
                {
                    if(i_x%2==0)
                    {
                        picture1.points.push_back(color[0]);
                    }
                    else
                    {
                        picture1.points.push_back(color[1]);
                    }
                }
            }
        }
    }

    for(i_x=0; i_x<picture1.width; i_x++)
    {
        picture_image1.coeffs.push_back((rand()%5)/10.0+0.5);
    }*/


    for(index=0; index<q_images; index++)
    {
        input[index].open(filenames[index]);

        input[index] >> picture1.width;
        input[index] >> picture1.height;

        picture1.points.resize(picture1.width*picture1.height);

        for(i_x=0; i_x<picture1.width; i_x++)
        {
            for(i_y=0; i_y<picture1.height; i_y++)
            {
                input[index] >> r;
                input[index] >> g;
                input[index] >> b;

                picture1.points[i_x+i_y*picture1.width].red   = r;
                picture1.points[i_x+i_y*picture1.width].green = g;
                picture1.points[i_x+i_y*picture1.width].blue  = b;
            }
        }
        pictures.push_back(picture1);
        input[index].close();
    }


    /*picture_image1.offset=0;

    picture_image1.color.red   = 255;
    picture_image1.color.green = 255;
    picture_image1.color.blue  = 255;

    pictures.push_back(picture1);
    picture_images.push_back(picture_image1);

    picture1.points.resize(0);*/

    /*picture1.width  = 100;
    picture1.height = 100;

    for(i_x=0; i_x<10; i_x++)
    {
        for(i_y=0; i_y<10; i_y++)
        {
            for(i_x1=0; i_x1<10; i_x1++)
            {
                for(i_y1=0; i_y1<10; i_y1++)
                {
                    if(i_y%5==0)
                    {
                        picture1.points.push_back(color[0]);
                    }
                    else
                    {
                        picture1.points.push_back(color[1]);
                    }
                }
            }
        }
    }

    picture_image1.coeffs.resize(0);

    for(i_x=0; i_x<picture1.width; i_x++)
    {
        picture_image1.coeffs.push_back((rand()%5)/10.0+0.5);
        cout << picture_image1.coeffs.back() << endl;
    }*/

    /*input[1].open("input2.txt");

    input[1] >> picture1.width;
    input[1] >> picture1.height;

    picture1.points.resize(picture1.width*picture1.height);

    for(i_x=0; i_x<picture1.width; i_x++)
    {
        for(i_y=0; i_y<picture1.height; i_y++)
        {
            input[1] >> r;
            input[1] >> g;
            input[1] >> b;

            picture1.points[i_x+i_y*picture1.width].red   = r;
            picture1.points[i_x+i_y*picture1.width].green = g;
            picture1.points[i_x+i_y*picture1.width].blue  = b;
        }
    }

    picture_image1.offset      = 0;

    picture_image1.color.red   = 255;
    picture_image1.color.green = 255;
    picture_image1.color.blue  = 0;

    pictures.push_back(picture1);
    picture_images.push_back(picture_image1);*/

}

void init_field(int num_field)
{
    int i_x, i_y;
    for(i_x=0; i_x<SCREEN_WIDTH_FOR_SCR_EFFECT; i_x++)
    {
        for(i_y=0; i_y<SCREEN_HEIGTH_FOR_SCR_EFFECT; i_y++)
        {
            field[i_x][i_y][num_field]         = rand()%10;
            colored_field[i_x][i_y][num_field] = 0;
        }
    }
}

void set_pixel_to_colored_field(int i_x, int i_y, int num_field)
{
    if(i_x<0 || i_x>=SCREEN_WIDTH_FOR_SCR_EFFECT || i_y<0 || i_y>=SCREEN_HEIGTH_FOR_SCR_EFFECT)
    {
        return;
    }
    colored_field[i_x][i_y][num_field] = 1;
}


void make_time_iteration_fields()
{
    int index;
    int i_x, i_y;

    for(index=0; index<Q_COLORED_FIELDS; index++)
    {
        colored_fields_times_now[index]-=10;

        if(colored_fields_times_now[index]<0)
        {
            colored_fields_times_now[index] = colored_fields_times[index];
            init_field(index);

            i_x = rand()%SCREEN_WIDTH_FOR_SCR_EFFECT;
            i_y = rand()%SCREEN_HEIGTH_FOR_SCR_EFFECT;

            set_pixel_to_colored_field(i_x, i_y, index);
        }
        make_iteration_field(index);
    }
}

void make_iteration_field(int num_field)
{
    int i_x, i_y;

    for(i_x=0; i_x<SCREEN_WIDTH_FOR_SCR_EFFECT; i_x++)
    {
        for(i_y=0; i_y<SCREEN_HEIGTH_FOR_SCR_EFFECT; i_y++)
        {
            if(colored_field[i_x][i_y][num_field] == 1)
            {
                field[i_x][i_y][num_field] -= 1;
                if(field[i_x][i_y][num_field] <= 0)
                {
                    set_pixel_to_colored_field(i_x+1, i_y, num_field);
                    set_pixel_to_colored_field(i_x-1, i_y, num_field);
                    set_pixel_to_colored_field(i_x, i_y+1, num_field);
                    set_pixel_to_colored_field(i_x, i_y-1, num_field);
                    set_pixel_to_colored_field(i_x+1, i_y+1, num_field);
                    set_pixel_to_colored_field(i_x-1, i_y+1, num_field);
                    set_pixel_to_colored_field(i_x+1, i_y-1, num_field);
                    set_pixel_to_colored_field(i_x-1, i_y-1, num_field);
                }
            }
        }
    }
}

void animate_pictures()
{
    int i_x, i_y, index, index_coeff;
    RGB_COLOR color1, color2;

    make_time_iteration_fields();
    show_picture();


    for(index=0; index<pictures.size(); index++)
    {
        picture_images[index].offset+=1;
        for(i_y=0; i_y<pictures[index].height; i_y++)
        {
            index_coeff = picture_images[index].offset + i_y*picture_images[index].coeffs.size()/pictures[index].height;

            while(index_coeff>=picture_images[index].coeffs.size())
            {
                index_coeff-=picture_images[index].coeffs.size();
            }



            for(i_x=0; i_x<pictures[index].width; i_x++)
            {
                color1 = pictures[index].points[i_x+i_y*pictures[index].width];

                color1.red   *= picture_images[index].coeffs[index_coeff];
                color1.green *= picture_images[index].coeffs[index_coeff];
                color1.blue  *= picture_images[index].coeffs[index_coeff];

                pictures[index].points[i_x+i_y*pictures[index].width] = color1;
            }
        }
    }
}

void set_pixel_picture(int x, int y, int index, RGB_COLOR color)
{
    if(x<0 || y<0 || index<0 || index>pictures.size())
    {
        return;
    }

    if(x>=pictures[index].width || y>=pictures[index].height)
    {
        return;
    }

    pictures[index].points[x+y*pictures[index].width] = color;
}

void show_picture()
{
    int i_x, i_y, index, index1, max_color, i_x1, i_y1, temp;
    RGB_COLOR color1;

    for(index=0; index<pictures.size(); index++)
    {
        for(i_x=0; i_x<SCREEN_WIDTH_FOR_SCR_EFFECT; i_x++)
        {
            for(i_y=0; i_y<SCREEN_HEIGTH_FOR_SCR_EFFECT; i_y++)
            {
                max_color = -1;

                for(index1=0; index1<Q_COLORED_FIELDS; index1++)
                {
                    max_color = max((int)(colored_field[i_x][i_y][index1]*(
                                    colored_fields_times_now[index1]*colored_fields_intensity[index1]/107)),
                                    max_color);
                }

                temp = max_color;

                if(index==0)
                {
                    color1.red   = 100;
                    color1.green = 0;
                    color1.blue  = 100;

                    color1.blue  = min(max_color+100, 255);
                    color1.red   -= 1.5*max_color;

                }
                else
                {
                    color1.red   = 255;
                    color1.green = 255;
                    color1.blue  = 255;

                    color1.red   -= 1.5*max_color;
                    color1.green -= 1.5*max_color;
                }


                for(i_x1=0; i_x1<ceil((double)pictures[index].width/SCREEN_WIDTH_FOR_SCR_EFFECT); i_x1++)
                {
                    for(i_y1=0; i_y1<ceil((double)pictures[index].height/SCREEN_HEIGTH_FOR_SCR_EFFECT); i_y1++)
                    {
                        set_pixel_picture(i_x*ceil((double)pictures[index].width/SCREEN_WIDTH_FOR_SCR_EFFECT)+i_x1,
                                            i_y*ceil((double)pictures[index].height/SCREEN_HEIGTH_FOR_SCR_EFFECT)+i_y1, index, color1);
                    }
                }
            }
        }
    }
}

void draw_pictures()
{
    int i_x, i_y;
    for(i_x=0; i_x<pictures[0].width; i_x++)
    {
        for(i_y=0; i_y<pictures[0].height; i_y++)
        {
            set_pixel_video_buf(i_x, i_y, pictures[0].points[i_x+i_y*pictures[0].width]);
        }
    }
}

