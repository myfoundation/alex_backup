#pragma once

struct RGB_COLOR
{
    unsigned char red;
    unsigned char green;
    unsigned char blue;
};

int screen_cx, screen_cy, pixel_bits;

BYTE*	video_buf;

void get_screen_parameters()
{
    _videomode_info(&screen_cx, &screen_cy, &pixel_bits);
}

void init_video_buf()
{
	int video_buf_len;

	video_buf_len = screen_cx*screen_cy*pixel_bits/8;

	video_buf = (BYTE*)malloc(video_buf_len);
}


void free_video_buf()
{
    free(video_buf);
}

void show_video_buf()
{
    int video_buf_len = screen_cx*screen_cy*pixel_bits/8;

	_screen_lock(true);
	memmove(MEMORY_0xA0000000, video_buf, video_buf_len);
	_screen_lock(false);
	_redraw_screen();
}

void set_pixel_video_buf(int x, int y, RGB_COLOR color)
{
    int video_buf_offset;

    if(x<0 || y<0 || x>=screen_cx || y>=screen_cy)
    {
        return;
    }

    video_buf_offset = (y*screen_cx+x)*pixel_bits/8;

    memRGB(video_buf, video_buf_offset, color.red, color.green, color.blue);
}
