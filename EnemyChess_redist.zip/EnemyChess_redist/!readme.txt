====================
 EN
====================
This is small, but funny console game ~3 min gameplay.
Destroy the enemy's chess pieces by jumping. Use the arrow keys: up, left, right.

====================
 RU
====================
Это небольшая, но забавная консольная игра с ~3-минутным игровым процессом.
Уничтожь прыжками шахматные фигуры врага. Используй клавиши стрелки: вверх, влево, вправо.

====================
РАЗРАБОТКА
====================
The graphics and the game world are in *.txt files.
Графика и игровой мир находятся в *.txt файлах.
